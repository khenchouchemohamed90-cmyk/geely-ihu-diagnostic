package com.aztech.voice;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Diagnostic ECARX en lecture seule, Android 9.
 * Ce code n'invoque AUCUNE methode set*, aucun CarProperty write,
 * aucune transaction brute Binder, aucune commande physique.
 * La phase d'initialisation Car.create(Context) est volontairement separee
 * et ne se lance QUE si l'utilisateur appuie sur son bouton.
 */
public final class EcarxReadOnlyProbe {
    public interface Listener { void onResult(String report); }
    private static final String TAG = "AZVoiceEcarx";
    private static final String[] TYPES = {
        "com.ecarx.xui.adaptapi.car.Car",
        "com.ecarx.xui.adaptapi.car.ICar",
        "com.ecarx.xui.adaptapi.car.base.ICarFunction",
        "com.ecarx.xui.adaptapi.car.vehicle.IBcm",
        "com.ecarx.xui.adaptapi.car.hvac.IHvac",
        "com.ecarx.xui.adaptapi.car.impl.CarImpl",
        "android.car.Car",
        "android.car.hardware.property.CarPropertyManager"
    };
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public EcarxReadOnlyProbe(Context context) {
        this.context = context.getApplicationContext();
    }

    public void inspect(Listener listener) {
        execute(false, listener);
    }
    public void connectWithoutCommands(Listener listener) {
        execute(true, listener);
    }

    private void execute(final boolean initialize, final Listener listener) {
        if (!busy.compareAndSet(false, true)) {
            listener.onResult("Un diagnostic ECARX est déjà en cours.");
            return;
        }
        new Thread(() -> {
            String result;
            try {
                result = initialize ? connectReport() : classReport();
            } catch (Throwable t) {
                result = "Diagnostic interrompu : " + causeText(t);
            }
            final String report = result;
            Log.i(TAG, "Début rapport (lecture seule)");
            for (String line : report.split("\n")) Log.i(TAG, line);
            busy.set(false);
            ui.post(() -> listener.onResult(report));
        }, initialize ? "AZVoice-ECARX-connect" : "AZVoice-ECARX-inspect").start();
    }

    private String classReport() {
        StringBuilder out = new StringBuilder("INSPECTION ADAPTERAPI (aucune initialisation OEM)\n");
        ClassLoader loader = context.getClassLoader();
        for (String name : TYPES) {
            try {
                Class<?> type = Class.forName(name, false, loader);
                out.append("[OK] ").append(name).append("\n");
                if (name.endsWith(".Car") || name.endsWith(".ICarFunction")) {
                    for (Method m : type.getDeclaredMethods()) {
                        String n = m.getName();
                        if ("create".equals(n) || "getICarFunction".equals(n)
                            || "getFunctionValue".equals(n) || "isFunctionSupported".equals(n)
                            || "setFunctionValue".equals(n)) {
                            out.append("    signature : ").append(m.toGenericString()).append("\n");
                        }
                    }
                }
            } catch (ClassNotFoundException e) {
                out.append("[ABSENT/INVISIBLE] ").append(name).append("\n");
            } catch (Throwable t) {
                out.append("[ERREUR] ").append(name).append(" : ").append(causeText(t)).append("\n");
            }
        }
        out.append("Aucune méthode OEM exécutée. La présence des classes ne vaut pas autorisation.\n");
        return out.toString();
    }

    private String connectReport() {
        StringBuilder out = new StringBuilder("INITIALISATION ECARX (aucune commande véhicule)\n");
        try {
            Class<?> car = Class.forName("com.ecarx.xui.adaptapi.car.Car", false, context.getClassLoader());
            Method create = null;
            // Accepte UNIQUEMENT la variante connue Car.create(Context) ; les autres
            // signatures ne sont pas invoquées à l'aveugle.
            for (Method m : car.getMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if ("create".equals(m.getName()) && Modifier.isStatic(m.getModifiers())
                    && p.length == 1 && p[0] == Context.class) {
                    create = m;
                    break;
                }
            }
            if (create == null) {
                out.append("[NON TENTÉ] Car.create(Context) indisponible. Voir inspection statique.\n");
                return out.toString();
            }
            out.append("[OK] Car.create(Context) disponible.\n");
            Object carObject = create.invoke(null, context);
            if (carObject == null) {
                out.append("[ÉCHEC] Car.create a retourné null.\n");
                return out.toString();
            }
            out.append("[OK] Objet API renvoyé : ").append(carObject.getClass().getName()).append("\n");
            // Accesseur d'interface uniquement; aucune lecture ou écriture de propriété.
            try {
                Method getFunction = carObject.getClass().getMethod("getICarFunction");
                Object function = getFunction.invoke(carObject);
                out.append(function == null
                    ? "[ATTENTION] getICarFunction() a retourné null.\n"
                    : "[OK] Objet ICarFunction obtenu : " + function.getClass().getName() + "\n");
            } catch (Throwable t) {
                out.append("[ERREUR] getICarFunction() : ").append(causeText(t)).append("\n");
            }
            out.append("Connexion de service, permissions métier et fonctions physiques NON validées.\n");
        } catch (Throwable t) {
            out.append("[ÉCHEC] ").append(causeText(t)).append("\n");
        }
        out.append("Aucune méthode setFunctionValue, getFunctionValue, aucun ordre moteur.\n");
        return out.toString();
    }

    private static String causeText(Throwable problem) {
        Throwable t = problem;
        if (t instanceof InvocationTargetException && ((InvocationTargetException)t).getTargetException() != null)
            t = ((InvocationTargetException)t).getTargetException();
        String message = t.getMessage();
        return t.getClass().getSimpleName() + (message == null ? "" : " : " + message);
    }
}
