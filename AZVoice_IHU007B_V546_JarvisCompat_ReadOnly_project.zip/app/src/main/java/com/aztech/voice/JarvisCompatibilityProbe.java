package com.aztech.voice;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.4.6 — diagnostic de compatibilite avec la logique ECARX observee dans Jarvis.
 * AUCUN appel Car.create(), connect(), getProperty(), setProperty(),
 * getFunctionValue(), setFunctionValue() ni aucune commande vehicule.
 * Seules sont inspectees les permissions propres a notre paquet et les SIGNATURES
 * des methodes disponibles dans le classloader du firmware.
 */
public final class JarvisCompatibilityProbe {
    private static final String TAG = "AZVoiceJarvisCompat";
    private static final String[] PERMISSIONS = {
        "android.car.permission.CAR_VENDOR_EXTENSION",
        "android.car.permission.CONTROL_CAR_CLIMATE",
        "android.car.permission.CONTROL_CAR_WINDOWS"
    };
    public interface Listener { void onResult(String result); }
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public JarvisCompatibilityProbe(Context context) {
        this.context = context.getApplicationContext();
    }

    public void runOnce(Listener callback) {
        if (!busy.compareAndSet(false, true)) {
            callback.onResult("Un diagnostic Jarvis/ECARX est deja en cours.");
            return;
        }
        new Thread(() -> {
            String report;
            try { report = inspect(); }
            catch (Throwable err) { report = "ERREUR: " + err.getClass().getSimpleName() + ": " + err.getMessage(); }
            for (String line : report.split("\n")) Log.i(TAG, line);
            busy.set(false);
            final String finalReport = report;
            ui.post(() -> callback.onResult(finalReport));
        }, "AZVoice-jarvis-static-readonly").start();
    }

    private String inspect() {
        StringBuilder out = new StringBuilder();
        out.append("AZ VOICE V5.4.6 / COMPATIBILITE JARVIS ECARX — METADONNEES UNIQUEMENT\n");
        out.append("Notre APK: ").append(context.getPackageName()).append('\n');
        String[] requested = null;
        try {
            PackageInfo pkg = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), PackageManager.GET_PERMISSIONS);
            requested = pkg.requestedPermissions;
        } catch (Throwable t) {
            out.append("Impossible de lire requestedPermissions: ").append(t.getClass().getSimpleName()).append('\n');
        }
        for (String name : PERMISSIONS) {
            boolean declared = false;
            if (requested != null) {
                for (String p : requested) if (name.equals(p)) { declared = true; break; }
            }
            boolean granted = context.checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED;
            out.append(name).append(": declaree=").append(declared)
               .append(" accordee=").append(granted).append('\n');
        }
        final ClassLoader loader = context.getClassLoader();
        inspectMethod(out, loader, "com.ecarx.xui.adaptapi.car.Car", "create", Context.class);
        inspectMethod(out, loader, "com.ecarx.xui.adaptapi.car.Car", "getICarFunction");
        String api = "com.ecarx.xui.adaptapi.car.base.ICarFunction";
        inspectMethod(out, loader, api, "isFunctionSupported", int.class);
        inspectMethod(out, loader, api, "isFunctionSupported", int.class, int.class);
        inspectMethod(out, loader, api, "getFunctionValue", int.class);
        inspectMethod(out, loader, api, "getFunctionValue", int.class, int.class);
        inspectMethod(out, loader, api, "setFunctionValue", int.class, int.class);
        inspectMethod(out, loader, api, "setFunctionValue", int.class, int.class, int.class);
        inspectMethod(out, loader, api, "setCustomizeFunctionValue", int.class, float.class);
        inspectMethod(out, loader, api, "setCustomizeFunctionValue", int.class, int.class, float.class);
        out.append("Lecture de signatures uniquement. Aucun service ouvert, aucune commande envoyee.\n");
        out.append("IMPORTANT: une methode presente ne prouve ni permission accordee ni compatibilite du vehicule.\n");
        return out.toString();
    }

    private static void inspectMethod(StringBuilder out, ClassLoader loader, String className,
                                      String methodName, Class<?>... parameters) {
        out.append(className).append('.').append(methodName).append('(');
        for (int i = 0; i < parameters.length; i++) {
            if (i > 0) out.append(',');
            out.append(parameters[i].getSimpleName());
        }
        out.append("): ");
        try {
            Class<?> c = Class.forName(className, false, loader);
            Method method = c.getMethod(methodName, parameters);
            out.append("PRESENTE retour=").append(method.getReturnType().getName());
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            out.append("ABSENTE ou non exposée (").append(e.getClass().getSimpleName()).append(')');
        } catch (Throwable t) {
            out.append("INDETERMINE (").append(t.getClass().getSimpleName()).append(')');
        }
        out.append('\n');
    }
}
