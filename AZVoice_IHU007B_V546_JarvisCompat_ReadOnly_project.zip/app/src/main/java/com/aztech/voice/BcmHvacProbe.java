package com.aztech.voice;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.4.3: BCM/HVAC diagnostic, read-only.
 * Connection observer and two time-separated support snapshots only.
 * No getFunctionValue(), setFunctionValue(), setProperty(), raw Binder,
 * permissions changes, OEM packages modification or actuator commands.
 */
public final class BcmHvacProbe {
    public interface Listener { void onResult(String result); }
    private static final String TAG = "AZVoiceBcmHvac";
    private static final String OEM_CAR = "com.ecarx.xui.adaptapi.car.Car";
    private static final String WATCHER = "com.ecarx.xui.adaptapi.binder.IConnectable$IConnectWatcher";
    private static final String BCM = "com.ecarx.xui.adaptapi.car.vehicle.IBcm";
    private static final String HVAC = "com.ecarx.xui.adaptapi.car.hvac.IHvac";
    private static final String[][] FUNCTIONS = {
        {BCM, "BCM_FUNC_WINDOW", "Vitres"},
        {BCM, "BCM_FUNC_WINDOW_POS", "Position des vitres"},
        {BCM, "BCM_FUNC_WINDOW_CURRENT_POS", "Position courante"},
        {BCM, "BCM_FUNC_SUNROOF_TILT", "Inclinaison toit"},
        {HVAC, "HVAC_FUNC_AC", "Climatisation A/C"},
        {HVAC, "HVAC_FUNC_TEMP", "Temperature de consigne"},
        {HVAC, "HVAC_FUNC_FAN_SPEED", "Ventilation"},
        {HVAC, "HVAC_FUNC_AUTO", "Mode automatique"}
    };
    private static final String[] PERMISSIONS = {
        "android.car.permission.CONTROL_CAR_WINDOWS",
        "android.car.permission.CONTROL_CAR_CLIMATE",
        "android.car.permission.CAR_VENDOR_EXTENSION"
    };

    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public BcmHvacProbe(Context ctx) { context = ctx.getApplicationContext(); }
    public void inspectStatic(Listener cb) { start(false, cb); }
    public void checkSupport(Listener cb) { start(true, cb); }

    private void start(boolean support, Listener cb) {
        if (!busy.compareAndSet(false, true)) {
            cb.onResult("Diagnostic BCM/HVAC deja en cours.");
            return;
        }
        new Thread(() -> {
            String result;
            try { result = run(support); }
            catch (Throwable e) { result = "[ERREUR] " + explain(e); }
            Log.i(TAG, support ? "V5.4.3 TEST CONNEXION / SUPPORT" : "V5.4.3 INVENTAIRE STATIQUE");
            for (String line : result.split("\n")) Log.i(TAG, line);
            busy.set(false);
            final String output = result;
            ui.post(() -> cb.onResult(output));
        }, support ? "AZVoice-bcmhvac-support" : "AZVoice-bcmhvac-static").start();
    }

    private String run(boolean support) {
        StringBuilder out = new StringBuilder("AZ VOICE V5.4.3 - BCM/HVAC DIAGNOSTIC (SANS COMMANDE)\n");
        ClassLoader loader = context.getClassLoader();
        out.append("8 fonctions documentees, aucun ID OEM inconnu.\n");
        out.append("Permissions de l'APK :\n");
        for (String p : PERMISSIONS) {
            try {
                out.append("  ").append(p).append(" : ")
                   .append(context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED ? "ACCORDEE" : "NON ACCORDEE")
                   .append('\n');
            } catch (Throwable t) {
                out.append("  ").append(p).append(" : ").append(explain(t)).append('\n');
            }
        }
        if (!support) {
            out.append("Inspection sans Car.create ni connexion constructeur.\n");
            for (String[] f : FUNCTIONS) {
                out.append(f[1]).append(" : ").append(resolveId(f, loader)).append('\n');
            }
            out.append("FIN. Aucun appel OEM execute.\n");
            return out.toString();
        }

        Object car = null;
        boolean openedByUs = false;
        boolean watcherRegistered = false;
        AtomicBoolean connectedEvent = new AtomicBoolean(false);
        AtomicBoolean disconnectedEvent = new AtomicBoolean(false);
        try {
            Class<?> carType = Class.forName(OEM_CAR, false, loader);
            Method create = carType.getMethod("create", Context.class);
            if (!Modifier.isStatic(create.getModifiers())) {
                out.append("[STOP] Car.create(Context) non statique.\n");
                return out.toString();
            }
            car = create.invoke(null, context);
            if (car == null) {
                out.append("[STOP] Car.create() == null.\n");
                return out.toString();
            }
            out.append("[OK] Car.create : ").append(car.getClass().getName()).append('\n');
            Method connect = car.getClass().getMethod("connect");
            Method isConnected = car.getClass().getMethod("isConnected");
            boolean ready = Boolean.TRUE.equals(isConnected.invoke(car));
            out.append("[OEM] Etat avant connexion : ").append(ready).append('\n');

            // Jarvis-inspired event observation, implemented independently via Java reflection.
            // Registration itself is a diagnostic action; never activates physical functions.
            try {
                Class<?> wt = Class.forName(WATCHER, false, loader);
                Object observer = Proxy.newProxyInstance(loader, new Class<?>[]{wt}, (proxy, method, args) -> {
                    String n = method.getName();
                    if ("onConnected".equals(n)) {
                        connectedEvent.set(true);
                        Log.i(TAG, "[OEM] Observateur IConnectWatcher.onConnected() recu");
                    } else if ("onDisConnected".equals(n)) {
                        disconnectedEvent.set(true);
                        Log.i(TAG, "[OEM] Observateur IConnectWatcher.onDisConnected() recu");
                    } else if ("equals".equals(n)) {
                        return args != null && args.length == 1 && proxy == args[0];
                    } else if ("hashCode".equals(n)) {
                        return System.identityHashCode(proxy);
                    } else if ("toString".equals(n)) {
                        return "AZVoiceReadOnlyConnectWatcher";
                    }
                    return null;
                });
                car.getClass().getMethod("registerConnectWatcher", wt).invoke(car, observer);
                watcherRegistered = true;
                out.append("[OEM] IConnectWatcher enregistre avant connect().\n");
            } catch (Throwable e) {
                out.append("[INFO] Observateur indisponible : ").append(explain(e))
                   .append(" ; controle isConnected maintenu.\n");
            }

            if (!ready) {
                openedByUs = true;
                out.append("[OEM] Appel connect() unique.\n");
                connect.invoke(car);
                long end = SystemClock.elapsedRealtime() + 8000;
                while (SystemClock.elapsedRealtime() < end) {
                    ready = Boolean.TRUE.equals(isConnected.invoke(car));
                    if (ready) break;
                    Thread.sleep(200);
                }
            }
            out.append("[OEM] isConnected apres connect : ").append(ready).append('\n');
            out.append("[OEM] onConnected observe : ").append(connectedEvent.get()).append('\n');
            if (!ready) {
                out.append("[STOP] Non connecte. Aucune verification de support executee.\n");
                return out.toString();
            }

            try {
                Class<?> configClass = Class.forName("android.car.carconfig.ECarxCarConfigManager", false, loader);
                out.append("[OEM] Classe car_config visible : ").append(configClass.getName()).append('\n');
            } catch (Throwable t) {
                out.append("[INFO] Classe car_config non visible : ").append(explain(t)).append('\n');
            }

            Object functions = car.getClass().getMethod("getICarFunction").invoke(car);
            if (functions == null) {
                out.append("[STOP] getICarFunction() == null.\n");
                return out.toString();
            }
            out.append("[OK] ICarFunction : ").append(functions.getClass().getName()).append('\n');
            Method supported = functions.getClass().getMethod("isFunctionSupported", int.class);

            // A bounded two-snapshot comparison to distinguish early initialization
            // from a stable status. Only metadata/support queries, never actuator reads/writes.
            out.append("[OEM] Support immediat apres connexion :\n");
            for (String[] f : FUNCTIONS) logStatus(out, f, loader, functions, supported);
            Thread.sleep(1200);
            out.append("[OEM] Support apres 1.2 s :\n");
            for (String[] f : FUNCTIONS) logStatus(out, f, loader, functions, supported);
            out.append("[OEM] Evenement onConnected observe : ").append(connectedEvent.get())
               .append(" ; onDisConnected observe : ").append(disconnectedEvent.get()).append('\n');
            out.append("[INFO] 'notavailable' n'est ni un refus de permission prouve ni une autorisation.\n");
            out.append("FIN - Aucun getFunctionValue/setFunctionValue/setProperty, aucun mouvement.\n");
            return out.toString();
        } catch (Throwable t) {
            if (t instanceof InterruptedException) Thread.currentThread().interrupt();
            out.append("[STOP] Diagnostic : ").append(explain(t)).append('\n');
            return out.toString();
        } finally {
            if (car != null && watcherRegistered) {
                try {
                    car.getClass().getMethod("unregisterConnectWatcher").invoke(car);
                    Log.i(TAG, "[OEM] IConnectWatcher desinscrit");
                } catch (Throwable t) {
                    Log.w(TAG, "[OEM] Desinscription observateur : " + explain(t));
                }
            }
            if (car != null && openedByUs) {
                try {
                    car.getClass().getMethod("disconnect").invoke(car);
                    Log.i(TAG, "[OEM] Deconnexion de notre session de diagnostic");
                } catch (Throwable t) {
                    Log.w(TAG, "[OEM] Deconnexion : " + explain(t));
                }
            }
        }
    }

    private static String resolveId(String[] f, ClassLoader loader) {
        try {
            Class<?> owner = Class.forName(f[0], false, loader);
            Field fld = owner.getField(f[1]);
            if (fld.getType() != int.class || !Modifier.isStatic(fld.getModifiers())) return "type incorrect";
            return "0x" + Integer.toHexString(fld.getInt(null));
        } catch (Throwable t) { return "indisponible : " + explain(t); }
    }
    private static void logStatus(StringBuilder out, String[] f, ClassLoader loader,
                                  Object functions, Method supported) {
        out.append("  ").append(f[1]).append(" [").append(resolveId(f, loader)).append("] : ");
        try {
            Class<?> owner = Class.forName(f[0], false, loader);
            int id = owner.getField(f[1]).getInt(null);
            Object status = supported.invoke(functions, id);
            out.append(status == null ? "null" : status.toString());
        } catch (Throwable t) { out.append(explain(t)); }
        out.append('\n');
    }
    private static String explain(Throwable error) {
        Throwable t = error;
        int i = 0;
        while (t instanceof InvocationTargetException && i++ < 4) {
            Throwable next = ((InvocationTargetException)t).getTargetException();
            if (next == null || next == t) break;
            t = next;
        }
        String msg = t.getMessage();
        return t.getClass().getSimpleName() + (msg == null ? "" : ": " + msg);
    }
}
