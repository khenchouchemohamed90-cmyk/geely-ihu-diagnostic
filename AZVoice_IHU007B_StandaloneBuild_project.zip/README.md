# AZ Voice — Android 9 (IHU007B) — APK autonome (projet compilable)

La version de ce projet construit une APK **avec le modèle vocal Vosk français inclus**. Aucune copie séparée du modèle dans la voiture n’est nécessaire. **Le présent dossier n’est pas une APK compilée.**

## Compilation en une fois via GitHub Actions

1. Envoyer les fichiers du projet dans un dépôt GitHub, y compris `.github/workflows/build-apk.yml`.
2. Ouvrir l’onglet **Actions** et démarrer **Build AZ Voice APK** (ou pousser sur `main`).
3. Le workflow télécharge le modèle officiel `vosk-model-small-fr-0.22` dans le dossier assets pendant la compilation.
4. Après le succès, récupérer l’artifact `AZVoice-IHU007B-debug-apk`, puis extraire `app-debug.apk` du ZIP.
5. Installer sur l'IHU007B stationné avec : `adb install -r app-debug.apk`.
6. Ouvrir **AZ Voice (test)** : le modèle se décompressera automatiquement au premier lancement, puis autoriser le microphone.

## Conditions

Android 9+ (API 28), sans Google Play Services. Usage uniquement hors ligne, aucune permission ECARX ni droits root.

Il s'agit **d'un test de transcription vocale française**, pas encore d'un assistant de commande véhicule. Elsie n'est ni remplacé ni désactivé. Il faut vérifier le fonctionnement du micro tiers sur l'IHU et les ressources mémoire disponibles.

## Dépendances

- Vosk Android 0.3.47 (`com.alphacephei:vosk-android:0.3.47`)
- Modèle français Vosk 0.22 (téléchargé à la compilation via le site officiel)
- Android Gradle Plugin 8.5.2 et Gradle 8.7, JDK 17 (GitHub Actions)

## Diagnostic

`adb logcat -d -s AZVoice:E AndroidRuntime:E`

`adb uninstall com.aztech.voice` pour supprimer le test.
