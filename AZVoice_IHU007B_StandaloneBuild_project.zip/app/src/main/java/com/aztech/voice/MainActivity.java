package com.aztech.voice;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;
import org.vosk.android.StorageService;

import java.io.File;
import java.io.IOException;

/**
 * AZ Voice, banc de test de reconnaissance vocale hors ligne pour IHU007B.
 * Ne prend aucune commande de contrôle automobile et ne modifie pas Xiaoka.
 */
public class MainActivity extends Activity implements RecognitionListener {
    private static final String TAG = "AZVoice";
    private static final int MIC_PERMISSION_REQUEST = 7;
    private static final float SAMPLE_RATE = 16000.0f;

    private TextView statusView;
    private TextView transcriptView;
    private TextView partialView;
    private TextView modelPathView;
    private Button loadButton;
    private Button micButton;
    private Model model;
    private SpeechService speechService;
    private Recognizer recognizer;
    private boolean loading = false;
    private boolean listening = false;
    private boolean stopping = false;
    private boolean destroyed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        File modelDir = getModelDirectory();
        if (modelDir == null) {
            setStatus("Stockage externe de l'application indisponible.");
        } else {
            modelPathView.setText("Stockage des modèles :\n" + modelDir.getAbsolutePath());
            if (!modelDir.isDirectory()) modelDir.mkdirs();
            setStatus("Préparation du modèle vocal français intégré...");
        }
        refreshButtons();
        loadModel();
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(20), dp(24), dp(16));
        root.setBackgroundColor(Color.rgb(245, 248, 251));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = makeText("AZ VOICE", 28, Color.rgb(20, 42, 65));
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);
        TextView subtitle = makeText("Test français hors ligne — Geely IHU007B (Android 9)", 16, Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(subtitle);

        statusView = makeText("Initialisation...", 18, Color.rgb(20, 82, 123));
        statusView.setPadding(0, dp(20), 0, dp(12));
        root.addView(statusView);

        loadButton = new Button(this);
        loadButton.setText("Réessayer le chargement du modèle");
        root.addView(loadButton);
        loadButton.setOnClickListener(v -> loadModel());

        micButton = new Button(this);
        micButton.setText("Démarrer le microphone");
        root.addView(micButton);
        micButton.setOnClickListener(v -> toggleMicrophone());

        TextView label = makeText("Texte reconnu :", 17, Color.BLACK);
        label.setPadding(0, dp(20), 0, 0);
        root.addView(label);

        transcriptView = makeText("(aucun résultat)", 22, Color.rgb(24, 53, 75));
        transcriptView.setPadding(dp(14), dp(10), dp(14), dp(10));
        transcriptView.setBackgroundColor(Color.WHITE);
        root.addView(transcriptView);

        partialView = makeText("", 16, Color.GRAY);
        root.addView(partialView);

        modelPathView = makeText("", 13, Color.GRAY);
        modelPathView.setPadding(0, dp(26), 0, dp(14));
        root.addView(modelPathView);

        TextView safe = makeText(
            "Cette application n'envoie pas la voix sur Internet, ne désactive pas Elsie/Xiaoka " +
            "et ne commande aucun élément du véhicule. À tester véhicule stationné.",
            14, Color.DKGRAY);
        root.addView(safe);
    }

    private TextView makeText(String s, int sp, int color) {
        TextView view = new TextView(this);
        view.setText(s);
        view.setTextColor(color);
        view.setTextSize(sp);
        return view;
    }

    private int dp(int amount) {
        return Math.round(getResources().getDisplayMetrics().density * amount);
    }

    private void setStatus(String msg) {
        if (statusView != null) statusView.setText(msg);
        Log.i(TAG, msg);
    }

    private File getModelDirectory() {
        File root = getExternalFilesDir(null);
        return root == null ? null : new File(root, "model-fr");
    }

    private void refreshButtons() {
        if (loadButton == null || micButton == null) return;
        loadButton.setEnabled(!loading && !listening && !stopping && model == null);
        micButton.setEnabled(model != null && !loading && !stopping);
        micButton.setText(listening ? "Arrêter l'écoute" : "Démarrer le microphone");
    }

    private void loadModel() {
        if (model != null || loading || destroyed) return;
        loading = true;
        setStatus("Chargement du modèle français intégré... Cela peut prendre un moment au premier lancement.");
        refreshButtons();
        try {
            // La compilation CI place le modèle complet dans assets/model-fr/.
            getAssets().open("model-fr/uuid").close();
            StorageService.unpack(this, "model-fr", "model", loadedModel -> {
                if (destroyed) { loadedModel.close(); return; }
                model = loadedModel;
                loading = false;
                setStatus("Modèle français prêt. Appuie sur Démarrer le microphone.");
                refreshButtons();
            }, exception -> {
                loading = false;
                setStatus("Impossible d'extraire le modèle intégré : " + exception.getMessage());
                refreshButtons();
            });
            return;
        } catch (IOException notBundled) {
            setStatus("Modèle français non intégré : il faut compiler par GitHub Actions.");
            loading = false;
            refreshButtons();
            return;
        }
    }

    private void toggleMicrophone() {
        if (stopping || loading || model == null) return;
        if (listening) {
            stopListening(false);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                startListening();
            } else {
                setStatus("Microphone refusé : autorise RECORD_AUDIO pour continuer.");
            }
        }
    }

    private void startListening() {
        if (model == null || listening || stopping || destroyed) return;
        try {
            recognizer = new Recognizer(model, SAMPLE_RATE);
            speechService = new SpeechService(recognizer, SAMPLE_RATE);
            speechService.startListening(this);
            listening = true;
            partialView.setText("");
            transcriptView.setText("Parle maintenant en français...");
            setStatus("Écoute en cours (hors ligne)");
        } catch (Exception | LinkageError error) {
            Log.e(TAG, "Microphone/ASR impossible", error);
            SpeechService svc = speechService;
            Recognizer rec = recognizer;
            speechService = null;
            recognizer = null;
            if (svc != null) svc.shutdown();
            if (rec != null) rec.close();
            listening = false;
            setStatus("Échec audio : " + error.getClass().getSimpleName() + " : " + error.getMessage());
        }
        refreshButtons();
    }

    private void stopListening(boolean silent) {
        if (!listening || stopping) return;
        listening = false;
        stopping = true;
        SpeechService svc = speechService;
        Recognizer rec = recognizer;
        speechService = null;
        recognizer = null;
        if (!silent) setStatus("Arrêt du microphone...");
        refreshButtons();
        new Thread(() -> {
            try {
                if (svc != null) {
                    svc.cancel();
                    svc.shutdown();
                }
                if (rec != null) rec.close();
            } catch (Exception e) {
                Log.e(TAG, "Erreur fermeture microphone", e);
            }
            runOnUiThread(() -> {
                stopping = false;
                if (!destroyed && !silent) setStatus("Microphone arrêté.");
                refreshButtons();
            });
        }, "AZVoice-mic-stop").start();
    }

    private String extract(String json, String key) {
        try {
            return new JSONObject(json).optString(key, "");
        } catch (JSONException e) {
            return "";
        }
    }

    @Override
    public void onPartialResult(String hypothesis) {
        final String text = extract(hypothesis, "partial");
        runOnUiThread(() -> {
            if (!destroyed && listening) partialView.setText(text);
        });
    }

    @Override
    public void onResult(String hypothesis) {
        final String text = extract(hypothesis, "text");
        runOnUiThread(() -> {
            if (!destroyed && !text.isEmpty()) {
                transcriptView.setText(text);
                partialView.setText("");
            }
        });
    }

    @Override
    public void onFinalResult(String hypothesis) {
        onResult(hypothesis);
    }

    @Override
    public void onError(Exception error) {
        Log.e(TAG, "Erreur Vosk", error);
        runOnUiThread(() -> {
            if (destroyed) return;
            setStatus("Erreur microphone : " + error.getMessage());
            if (listening) stopListening(true);
        });
    }

    @Override
    public void onTimeout() {
        runOnUiThread(() -> {
            if (listening) stopListening(false);
        });
    }

    @Override
    protected void onStop() {
        if (listening) stopListening(true);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        if (listening) stopListening(true);
        // Le modèle sera libéré au prochain arrêt du processus Android.
        // Ne pas le fermer ici avant la terminaison du thread audio.
        super.onDestroy();
    }
}
