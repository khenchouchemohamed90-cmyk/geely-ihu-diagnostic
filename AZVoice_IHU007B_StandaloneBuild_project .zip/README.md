# AZ Voice V2 — Diagnostic micro IHU007B

Compare MIC (1), VOICE_RECOGNITION (6) et VOICE_COMMUNICATION (7). Mesure niveau RMS en dBFS, pic d'amplitude, échantillons non nuls.

Enregistrement audio local volontaire de 8 secondes lors d'un test, uniquement après un clic sur le bouton. Fichier sous Android/data/com.aztech.voice/files/azvoice-source-N-*.wav, récupérable via ADB dans le dossier de fichiers externe de l'application. Pas de partage réseau ni d'enregistrement continu.

Etapes: à l'arrêt, fermer Xiaoka, lancer l'écoute, parler puis choisir 'Enregistrer 8 secondes'. Recommencer avec chaque source après avoir arrêté l'écoute.

Le modèle Vosk français est ajouté lors de la compilation GitHub. Aucun contrôle véhicule, aucune permission système.
