#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/azvoice-v3-tests
javac -encoding UTF-8 -d /tmp/azvoice-v3-tests app/src/main/java/com/aztech/voice/VoiceCommandParser.java tests/VoiceCommandParserTest.java
java -cp /tmp/azvoice-v3-tests VoiceCommandParserTest
