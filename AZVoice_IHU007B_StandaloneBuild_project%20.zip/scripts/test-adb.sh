#!/bin/sh
set -eu
if [ $# -ne 1 ]; then echo "Usage : sh scripts/test-adb.sh CHEMIN_VERS_app-debug.apk"; exit 1; fi
adb devices
adb install -r "$1"
adb shell am start -n com.aztech.voice.v3/com.aztech.voice.MainActivity
printf '\nAZ Voice V3 simulation lancee. Modele integre par workflow GitHub.\n'
