package com.aztech.voice;

import java.text.Normalizer;
import java.util.Locale;

/**
 * Interpreteur de commandes EN MODE SIMULATION SEULEMENT.
 * Sans API ECARX, sans CAN, sans controle de vitres ou toit, sans commande systeme.
 */
public final class VoiceCommandParser {
    private VoiceCommandParser() {}

    public static final class Command {
        public final String type;
        public final String target;
        public final String label;

        Command(String type, String target, String label) {
            this.type = type;
            this.target = target;
            this.label = label;
        }
    }

    static String normalize(String input) {
        if (input == null) return "";
        String s = Normalizer.normalize(input.toLowerCase(Locale.FRANCE), Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "")
            .replaceAll("[^a-z0-9]+", " ").trim();
        return " " + s.replaceAll("\\s+", " ") + " ";
    }

    private static boolean has(String s, String token) {
        return s.contains(" " + token + " ");
    }

    public static Command parse(String transcript) {
        String s = normalize(transcript);
        if (s.length() < 5 || s.length() > 190) return null;
        // Si la phrase exprime la negation ou une annulation, aucune commande.
        if (has(s,"pas") || has(s,"jamais") || has(s,"annule") || has(s,"annuler")
            || has(s,"ne") || has(s,"sans")) return null;

        boolean open = has(s,"ouvre") || has(s,"ouvrir") || has(s,"baisse") || has(s,"descends");
        boolean close = has(s,"ferme") || has(s,"fermer") || has(s,"remonte") || has(s,"monte");
        boolean stop = has(s,"arrete") || has(s,"stop") || has(s,"stoppe");
        // Plusieurs actions possibles : refus plutot qu'un choix arbitraire.
        if ((open ? 1 : 0) + (close ? 1 : 0) + (stop ? 1 : 0) != 1) return null;
        String action = open ? "OUVRIR" : (close ? "FERMER" : "ARRETER");
        String verb = open ? "Ouvrir" : (close ? "Fermer" : "Arrêter");

        boolean sunroof = has(s,"toit") && (has(s,"ouvrant") || has(s,"panoramique"));
        boolean window = has(s,"vitre") || has(s,"vitres") || has(s,"fenetre") || has(s,"fenetres");
        if (sunroof == window) return null; // ni l'un ni l'autre ou ambiguité

        if (sunroof) {
            return new Command(action, "TOIT_OUVRANT", verb + " le toit ouvrant");
        }

        if (stop) return null; // stop vitre non gere sans specifications supplementaires
        boolean all = has(s,"toutes") || has(s,"tous") || has(s,"ensemble");
        boolean front = has(s,"avant");
        boolean rear = has(s,"arriere");
        boolean left = has(s,"gauche");
        boolean right = has(s,"droite");
        boolean driver = has(s,"conducteur") || has(s,"chauffeur");
        boolean passenger = has(s,"passager") || has(s,"passagere");
        if (all) {
            if (front || rear || left || right || driver || passenger) return null;
            return new Command(action, "TOUTES_VITRES", verb + " toutes les vitres");
        }
        // Refuser les directions contradictoires et les zones incompletes.
        if ((left && right) || (front && rear) || (driver && passenger)) return null;
        if (driver && (rear || right || passenger)) return null;
        if (passenger && (rear || left || driver)) return null;
        if (driver) return new Command(action, "AVANT_GAUCHE", verb + " la vitre conducteur");
        if (passenger) return new Command(action, "AVANT_DROITE", verb + " la vitre passager");
        if (rear && left) return new Command(action, "ARRIERE_GAUCHE", verb + " la vitre arrière gauche");
        if (rear && right) return new Command(action, "ARRIERE_DROITE", verb + " la vitre arrière droite");
        if (front && left) return new Command(action, "AVANT_GAUCHE", verb + " la vitre avant gauche");
        if (front && right) return new Command(action, "AVANT_DROITE", verb + " la vitre avant droite");
        return null;
    }
}
