package com.aztech.voice;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.StorageService;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Banc de test audio ECARX, aucune action sur le vehicule. */
public class MainActivity extends Activity {
    private static final String TAG = "AZVoice";
    private static final int PERMISSION_REQUEST = 7;
    private static final int SAMPLE_RATE = 16000;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile AudioRecord activeRecorder;
    private volatile Thread audioThread;
    private volatile boolean destroyed = false;
    private volatile boolean loading = false;
    private Model model;
    private volatile boolean requestWav = false;
    private volatile boolean recordingWav = false;

    private Spinner sourceSpinner;
    private Button micButton;
    private Button reloadButton;
    private TextView status, meterText, transcript, interim, details;
    private ProgressBar meter;
    private TextView commandPreview;
    private Button confirmCommand, cancelCommand;
    private VoiceCommandParser.Command pendingCommand;
    private int recognitionSession = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setupUi();
        loadModel();
    }

    private TextView text(String initial, int sp) {
        TextView view = new TextView(this);
        view.setText(initial);
        view.setTextSize(sp);
        view.setTextColor(Color.rgb(29, 44, 63));
        view.setPadding(0, 8, 0, 8);
        return view;
    }

    private void setupUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 16, 24, 18);
        root.setBackgroundColor(Color.rgb(246, 248, 252));
        ScrollView scroller = new ScrollView(this);
        scroller.addView(root);
        setContentView(scroller);

        TextView header = text("AZ VOICE V3 · COMMANDES FRANÇAISES", 23);
        header.setGravity(Gravity.CENTER);
        root.addView(header);
        root.addView(text("Geely IHU007B · Français hors ligne · Simulation uniquement", 14));
        status = text("Chargement du modèle français...", 17);
        root.addView(status);

        root.addView(text("Source audio Android", 16));
        sourceSpinner = new Spinner(this);
        String[] sources = {"MIC (1) - recommandé", "VOICE_RECOGNITION (6)", "VOICE_COMMUNICATION (7)"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, sources);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceSpinner.setAdapter(adapter);
        root.addView(sourceSpinner);

        micButton = new Button(this);
        micButton.setText("Démarrer le test du microphone");
        micButton.setEnabled(false);
        micButton.setOnClickListener(v -> {
            if (running.get()) stopAudio();
            else checkPermissionAndStart();
        });
        root.addView(micButton);

        root.addView(text("Commandes reconnues : vitres et toit (aucun mouvement réel)", 17));
        commandPreview = text("Prononce par exemple : Ouvre la vitre conducteur", 16);
        root.addView(commandPreview);
        confirmCommand = new Button(this);
        confirmCommand.setText("Confirmer — SIMULATION");
        confirmCommand.setVisibility(View.GONE);
        confirmCommand.setOnClickListener(v -> {
            if (pendingCommand == null) return;
            String label = pendingCommand.label;
            clearCommandUi();
            commandPreview.setText("SIMULATION VALIDÉE : " + label + "\nAucune action envoyée au véhicule.");
            Log.i(TAG, "COMMANDE_SIMULEE " + label);
        });
        root.addView(confirmCommand);
        cancelCommand = new Button(this);
        cancelCommand.setText("Annuler");
        cancelCommand.setVisibility(View.GONE);
        cancelCommand.setOnClickListener(v -> {
            clearCommandUi();
            commandPreview.setText("Commande annulée. Aucun mouvement du véhicule.");
        });
        root.addView(cancelCommand);


        reloadButton = new Button(this);
        reloadButton.setText("Recharger le modèle français");
        reloadButton.setOnClickListener(v -> loadModel());
        root.addView(reloadButton);
        Button wavButton = new Button(this);
        wavButton.setText("Enregistrer 8 secondes de WAV (pendant l'écoute)");
        wavButton.setOnClickListener(v -> {
            if (!running.get()) {
                setStatus("Démarre d'abord l'écoute, puis appuie sur Enregistrer WAV.");
            } else if (recordingWav || requestWav) {
                setStatus("Enregistrement WAV déjà demandé / en cours.");
            } else {
                requestWav = true;
                setStatus("Enregistrement WAV demandé (8 secondes).");
            }
        });
        root.addView(wavButton);

        root.addView(text("Volume reçu depuis l'IHU", 17));
        meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        meter.setMax(100);
        meter.setProgress(0);
        root.addView(meter);
        meterText = text("En attente de capture audio", 16);
        root.addView(meterText);

        root.addView(text("Texte reconnu", 17));
        transcript = text("(aucun texte)", 20);
        transcript.setBackgroundColor(Color.WHITE);
        root.addView(transcript);
        interim = text("", 15);
        root.addView(interim);

        details = text("Le niveau et les échantillons permettront de diagnostiquer une entrée muette.", 14);
        root.addView(details);
        root.addView(text("ATTENTION : V3 ne pilote PAS les vitres, le toit ou le véhicule. Aucune connexion ECARX. Test uniquement à l'arrêt.", 14));
    }

    private void setStatus(String text) {
        if (status != null) status.setText(text);
        Log.i(TAG, text);
    }

    private void loadModel() {
        if (loading || model != null || destroyed) return;
        loading = true;
        reloadButton.setEnabled(false);
        micButton.setEnabled(false);
        setStatus("Chargement du modèle Vosk français...");
        StorageService.unpack(this, "model-fr", "model", loaded -> {
            if (destroyed) { loaded.close(); return; }
            model = loaded;
            loading = false;
            setStatus("Modèle français prêt. Source MIC (1) recommandée.");
            micButton.setEnabled(true);
            reloadButton.setEnabled(false);
        }, problem -> {
            loading = false;
            setStatus("Modèle indisponible : " + problem.getMessage());
            reloadButton.setEnabled(true);
        });
    }

    private void checkPermissionAndStart() {
        if (model == null || running.get()) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        startAudio();
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == PERMISSION_REQUEST) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startAudio();
            else setStatus("Permission RECORD_AUDIO refusée");
        }
    }

    private void startAudio() {
        if (model == null || !running.compareAndSet(false, true)) return;
        final int position = sourceSpinner.getSelectedItemPosition();
        final int source = position == 0 ? MediaRecorder.AudioSource.MIC :
            (position == 1 ? MediaRecorder.AudioSource.VOICE_RECOGNITION : MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        sourceSpinner.setEnabled(false);
        recognitionSession++;
        clearCommandUi();
        commandPreview.setText("Prêt : Ouvre la vitre conducteur / Ferme le toit ouvrant");
        micButton.setText("Arrêter l'écoute");
        meter.setProgress(0);
        meterText.setText("Démarrage de la capture...");
        transcript.setText("(en attente de parole)");
        interim.setText("");
        details.setText("Source sélectionnée : " + source + " | fréquence : 16000 Hz");
        setStatus("Initialisation du microphone (source " + source + ")...");
        audioThread = new Thread(() -> captureLoop(source), "AZVoice-AudioDiagnostic");
        audioThread.start();
    }

    private void captureLoop(int source) {
        AudioRecord recorder = null;
        Recognizer recognizer = null;
        int totalReads = 0;
        long totalSamples = 0;
        long lastUi = 0;
        String latestPartial = "";
        ByteArrayOutputStream wavData = null;
        int wavSamplesRemaining = 0;
        try {
            int minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBuffer <= 0) throw new IOException("Fréquence 16000 Hz refusée (code " + minBuffer + ")");
            int bufferBytes = Math.max(minBuffer * 2, 8192);
            recorder = new AudioRecord(source, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED)
                throw new IOException("AudioRecord non initialisé (source " + source + ")");
            activeRecorder = recorder;
            recognizer = new Recognizer(model, SAMPLE_RATE);
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING)
                throw new IOException("startRecording échoué pour source " + source);
            final String route;
            AudioDeviceInfo device = recorder.getRoutedDevice();
            route = device == null ? "inconnue" : ("type " + device.getType() + " / " + device.getProductName());
            runOnUiThread(() -> { if (!destroyed && running.get()) {
                setStatus("Écoute réelle active · source " + source);
                details.setText("Microphone Android : " + route + " | entrée " + source);
            }});
            short[] samples = new short[2048];
            while (running.get()) {
                int n = recorder.read(samples, 0, samples.length);
                if (n < 0) throw new IOException("Erreur lecture AudioRecord : " + n);
                if (n == 0) continue;
                totalReads++;
                totalSamples += n;
                if (requestWav && !recordingWav) {
                    requestWav = false;
                    recordingWav = true;
                    wavData = new ByteArrayOutputStream(8 * SAMPLE_RATE * 2);
                    wavSamplesRemaining = 8 * SAMPLE_RATE;
                    Log.i(TAG, "WAV_DEBUT source=" + source);
                    runOnUiThread(() -> setStatus("Enregistrement WAV 8 secondes en cours..."));
                }
                if (recordingWav && wavData != null) {
                    int frameCount = Math.min(n, wavSamplesRemaining);
                    for (int i = 0; i < frameCount; i++) {
                        wavData.write(samples[i] & 0xff);
                        wavData.write((samples[i] >>> 8) & 0xff);
                    }
                    wavSamplesRemaining -= frameCount;
                    if (wavSamplesRemaining <= 0) {
                        final byte[] pcm = wavData.toByteArray();
                        wavData = null;
                        recordingWav = false;
                        final File folder = getExternalFilesDir(null);
                        if (folder == null) throw new IOException("Dossier WAV Android inaccessible");
                        final File outFile = new File(folder, "azvoice-source-" + source + "-" + System.currentTimeMillis() + ".wav");
                        try (FileOutputStream output = new FileOutputStream(outFile)) {
                            output.write(wavHeader(pcm.length));
                            output.write(pcm);
                        }
                        Log.i(TAG, "WAV_ENREGISTRE " + outFile.getAbsolutePath() + " octets=" + pcm.length);
                        runOnUiThread(() -> {if (!destroyed) {
                            setStatus("WAV enregistré : " + outFile.getName());
                            details.setText("Fichier WAV local : " + outFile.getAbsolutePath());
                        }});
                    }
                }
                double sum = 0;
                int peak = 0, nonzero = 0;
                for (int i = 0; i < n; i++) {
                    int sample = samples[i];
                    sum += (double) sample * sample;
                    peak = Math.max(peak, Math.abs(sample));
                    if (sample != 0) nonzero++;
                }
                final double rms = Math.sqrt(sum / n);
                final double db = rms == 0 ? -120.0 : 20.0 * Math.log10(rms / 32768.0);
                final int progress = Math.max(0, Math.min(100, (int)Math.round((db + 70.0) * 100.0 / 70.0)));
                final int finalPeak = peak;
                final int finalNonzero = nonzero;
                final int finalN = n;
                final long count = totalSamples;
                final int reads = totalReads;
                long now = android.os.SystemClock.uptimeMillis();
                if (now - lastUi >= 300) {
                    lastUi = now;
                    runOnUiThread(() -> { if (!destroyed && running.get()) {
                        meter.setProgress(progress);
                        meterText.setText(String.format(java.util.Locale.US,
                            "Signal : %.1f dBFS | pic : %d | non nuls : %d/%d", db, finalPeak, finalNonzero, finalN));
                        details.setText("Source : " + source + " | lectures : " + reads + " | échantillons : " + count + " | fréquence : 16000 Hz");
                    }});
                    Log.i(TAG, String.format(java.util.Locale.US,
                        "AUDIO source=%d rmsDb=%.1f peak=%d nonzero=%d/%d reads=%d",source,db,finalPeak,finalNonzero,finalN,reads));
                }
                if (recognizer.acceptWaveForm(samples, n)) {
                    String result = new JSONObject(recognizer.getResult()).optString("text", "");
                    if (!result.isEmpty()) {
                        final VoiceCommandParser.Command parsed = VoiceCommandParser.parse(result);
                        final int sessionSnapshot = recognitionSession;
                        runOnUiThread(() -> { if (!destroyed && running.get() && sessionSnapshot == recognitionSession) {
                            transcript.setText(result);
                            interim.setText("");
                            presentCommand(parsed);
                        }});
                        Log.i(TAG, "ASR texte=" + result);
                    }
                } else {
                    String partial = new JSONObject(recognizer.getPartialResult()).optString("partial", "");
                    if (!partial.equals(latestPartial)) {
                        latestPartial = partial;
                        if (!partial.isEmpty())
                            runOnUiThread(() -> {if (!destroyed && running.get()) interim.setText("En cours : " + partial);});
                    }
                }
            }
        } catch (Exception | LinkageError e) {
            if (running.get()) {
                Log.e(TAG, "DIAGNOSTIC_AUDIO_ERREUR", e);
                final String msg = "Erreur capture : " + e.getClass().getSimpleName() + " : " + e.getMessage();
                runOnUiThread(() -> {if (!destroyed) setStatus(msg);});
            }
        } finally {
            requestWav = false;
            recordingWav = false;
            try { if (recorder != null && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); }
            catch (Exception ignored) {}
            if (recorder != null) recorder.release();
            activeRecorder = null;
            if (recognizer != null) recognizer.close();
            running.set(false);
            runOnUiThread(() -> {if (!destroyed) {
                micButton.setText("Démarrer le test du microphone");
                sourceSpinner.setEnabled(true);
                if (status.getText().toString().startsWith("Écoute réelle active")) setStatus("Écoute arrêtée");
            }});
        }
    }

    private void presentCommand(VoiceCommandParser.Command parsed) {
        clearCommandUi();
        if (parsed == null) {
            commandPreview.setText("Aucune commande précise reconnue. Répète une phrase complète.");
            return;
        }
        pendingCommand = parsed;
        commandPreview.setText("Commande comprise : " + parsed.label
            + "\nMode SIMULATION : confirmation sans action véhicule.");
        confirmCommand.setVisibility(View.VISIBLE);
        cancelCommand.setVisibility(View.VISIBLE);
    }

    private void clearCommandUi() {
        pendingCommand = null;
        if (confirmCommand != null) confirmCommand.setVisibility(View.GONE);
        if (cancelCommand != null) cancelCommand.setVisibility(View.GONE);
    }

    private static byte[] wavHeader(int pcmBytes) {
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R','I','F','F'});
        b.putInt(36 + pcmBytes);
        b.put(new byte[]{'W','A','V','E','f','m','t',' '});
        b.putInt(16); // PCM format block size
        b.putShort((short) 1); // PCM uncompressed
        b.putShort((short) 1); // mono
        b.putInt(SAMPLE_RATE);
        b.putInt(SAMPLE_RATE * 2); // byte rate
        b.putShort((short) 2); // block align
        b.putShort((short) 16); // bits per sample
        b.put(new byte[]{'d','a','t','a'});
        b.putInt(pcmBytes);
        return b.array();
    }

    private void stopAudio() {
        recognitionSession++;
        clearCommandUi();
        if (!running.getAndSet(false)) return;
        setStatus("Arrêt en cours...");
        AudioRecord record = activeRecorder;
        if (record != null) {
            try { if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) record.stop(); }
            catch (Exception e) { Log.w(TAG, "Arrêt anticipé : " + e.getMessage()); }
        }
    }

    @Override protected void onStop() {
        stopAudio();
        super.onStop();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        stopAudio();
        super.onDestroy();
    }
}
