package com.aztech.voice;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.4.4: diagnostic ciblé car_config en lecture seule, sans actionnement.
 * Les IDs sont uniquement ceux corroborés par les dumpsys HAL du IHU007B.
 * Aucun appel à getProperty (byte[]), setProperty, setFunctionValue ou Binder brut.
 */
public final class CarConfigProbe {
    public interface Listener { void onResult(String text); }
    private static final String TAG = "AZVoiceCarConfig";
    private static final String CONFIG_SERVICE = "car_config";
    // Liste fermée. AUCUN balayage des IDs constructeur.
    private static final int[][] IDS = {
        {0x2E700121, 0}, // A/C, comparaison avec la conversion AdaptAPI
        {0x2E700125, 0}, // ventilation
        {0x2E700127, 0}, // température zone 1
        {0x2E700128, 0}, // température zone 2
        {0x2E70012D, 0}, // AUTO
        {0x2E700249, 0}  // inclinaison du toit
    };
    private static final String[] NAMES = {
        "HVAC AC", "HVAC ventilateur", "HVAC temperature 1", "HVAC temperature 2", "HVAC AUTO", "BCM inclinaison toit"
    };
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public CarConfigProbe(Context ctx) { context = ctx.getApplicationContext(); }

    public void runOnce(Listener callback) {
        if (!busy.compareAndSet(false, true)) {
            callback.onResult("Un diagnostic car_config est deja en cours.");
            return;
        }
        new Thread(() -> {
            String result;
            try { result = runReadOnly(); }
            catch (Throwable t) { result = "[ERREUR] " + explain(t); }
            Log.i(TAG, "V5.4.4 DIAGNOSTIC CAR_CONFIG (lecture seule)");
            for (String line : result.split("\n")) Log.i(TAG, line);
            busy.set(false);
            final String msg = result;
            ui.post(() -> callback.onResult(msg));
        }, "AZVoice-carconfig-readonly").start();
    }

    private String runReadOnly() {
        StringBuilder out = new StringBuilder("CAR_CONFIG V5.4.4 — lecture seule, aucun mouvement\n");
        out.append("CONTROL_CAR_CLIMATE: ")
            .append(granted("android.car.permission.CONTROL_CAR_CLIMATE")).append('\n');
        out.append("CONTROL_CAR_WINDOWS: ")
            .append(granted("android.car.permission.CONTROL_CAR_WINDOWS")).append('\n');
        out.append("CAR_VENDOR_EXTENSION: ")
            .append(granted("android.car.permission.CAR_VENDOR_EXTENSION")).append('\n');
        Object car = null;
        try {
            ClassLoader cl = context.getClassLoader();
            Class<?> carClass = Class.forName("android.car.Car", false, cl);
            Method create = carClass.getMethod("createCar", Context.class, ServiceConnection.class);
            CountDownLatch latch = new CountDownLatch(1);
            ServiceConnection conn = new ServiceConnection() {
                @Override public void onServiceConnected(ComponentName name, IBinder binder) { latch.countDown(); }
                @Override public void onServiceDisconnected(ComponentName name) { }
            };
            car = create.invoke(null, context, conn);
            if (car == null) { out.append("[STOP] android.car.Car.createCar a renvoye null.\n"); return out.toString(); }
            Method isConnected = carClass.getMethod("isConnected");
            boolean ready = Boolean.TRUE.equals(isConnected.invoke(car));
            if (!ready) {
                carClass.getMethod("connect").invoke(car);
                latch.await(5, TimeUnit.SECONDS);
                ready = Boolean.TRUE.equals(isConnected.invoke(car));
            }
            out.append("[ANDROID CAR] isConnected=").append(ready).append('\n');
            if (!ready) { out.append("[STOP] Aucun appel car_config sans connexion.\n"); return out.toString(); }
            Object manager;
            try { manager = carClass.getMethod("getCarManager", String.class).invoke(car, CONFIG_SERVICE); }
            catch (Throwable t) {
                out.append(root(t) instanceof SecurityException ? "[PERMISSION REFUSEE] " : "[ERREUR CAR_CONFIG] ")
                   .append(explain(t)).append('\n');
                return out.toString();
            }
            if (manager == null) { out.append("[STOP] getCarManager(car_config) = null.\n"); return out.toString(); }
            out.append("[OK] Gestionnaire car_config obtenu: ").append(manager.getClass().getName()).append('\n');
            Class<?> configClass = Class.forName("android.car.carconfig.ECarxCarConfigManager", false, cl);
            if (!configClass.isInstance(manager)) {
                out.append("[STOP] Type constructeur inattendu. Aucune methode appelee.\n");
                return out.toString();
            }
            Method check;
            try { check = configClass.getMethod("isSupportFunctionSupported", int.class, int.class, int.class); }
            catch (NoSuchMethodException e) {
                out.append("[STOP] Signature isSupportFunctionSupported(int,int,int) absente.\n");
                return out.toString();
            }
            out.append("[OK] Verification de configuration accessible. Valeurs brutes non interpretees.\n");
            // Pour éviter de deviner les zones et operations du constructeur,
            // on ne teste que (zone=0, operation=0) sur une liste connue.
            // Cela ne démontre PAS qu'une fonction est indisponible sur d'autres zones.
            for (int i = 0; i < IDS.length; i++) {
                int id = IDS[i][0];
                out.append(NAMES[i]).append(" [0x").append(Integer.toHexString(id))
                   .append(", zone=0, operation=0]: ");
                try {
                    Object r = check.invoke(manager, id, 0, 0);
                    out.append("reponse brute=").append(String.valueOf(r));
                } catch (Throwable t) {
                    out.append(root(t) instanceof SecurityException ? "PERMISSION REFUSEE: " : "ERREUR: ")
                       .append(explain(t));
                }
                out.append('\n');
            }
            out.append("FIN — aucune lecture d'octets constructeur, aucun set, aucune commande.\n");
        } catch (Throwable t) {
            if (t instanceof InterruptedException) Thread.currentThread().interrupt();
            out.append(root(t) instanceof SecurityException ? "[PERMISSION REFUSEE] " : "[ERREUR] ")
               .append(explain(t)).append('\n');
        } finally {
            if (car != null) {
                try { car.getClass().getMethod("disconnect").invoke(car); }
                catch (Throwable t) { Log.w(TAG, "Deconnexion car_service: " + explain(t)); }
            }
        }
        return out.toString();
    }

    private String granted(String name) {
        try { return context.checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED ? "OUI" : "NON"; }
        catch (Throwable t) { return "INCONNU (" + explain(t) + ")"; }
    }
    private static Throwable root(Throwable t) {
        for (int i = 0; i < 4 && t instanceof InvocationTargetException; i++) {
            Throwable n = ((InvocationTargetException)t).getTargetException();
            if (n == null || n == t) break;
            t = n;
        }
        return t;
    }
    private static String explain(Throwable t) {
        Throwable e = root(t);
        return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
    }
}
