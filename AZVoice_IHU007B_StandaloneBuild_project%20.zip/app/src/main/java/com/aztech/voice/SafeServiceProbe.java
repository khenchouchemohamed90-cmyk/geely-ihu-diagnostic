package com.aztech.voice;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

/**
 * Probe de liaison NON OPERATIONNEL vers le service Xiaoka.
 * Aucune methode ECARX, action vehicule, commande CAN ou ecriture de propriete.
 * bindService sans BIND_AUTO_CREATE: ne demande pas la creation d'un service absent.
 * getInterfaceDescriptor lit seulement l'identite du binder systeme.
 */
public final class SafeServiceProbe implements ServiceConnection {
    private static final String TAG = "AZVoiceProbe";
    private static final ComponentName TARGET = new ComponentName(
        "com.ecarx.xiaoka.carcontrol",
        "com.ecarx.xiaoka.carcontrol.service.CarControlService");

    public interface Listener { void onResult(String message); }

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;
    private boolean bound;
    private boolean finished;

    public SafeServiceProbe(Context context) { this.context = context; }

    public void run(Listener listener) {
        if (bound) {
            listener.onResult("Test déjà en cours.");
            return;
        }
        this.listener = listener;
        finished = false;
        Intent request = new Intent().setComponent(TARGET);
        try {
            // Pas de BIND_AUTO_CREATE, aucun lancement explicite de service.
            bound = context.bindService(request, this, 0);
            if (!bound) {
                report("Connexion refusée ou service indisponible (bindService=false). "
                    + "Aucune commande envoyée.");
                return;
            }
            handler.postDelayed(() -> {
                if (!finished) {
                    report("Délai dépassé : aucun Binder reçu après 5 secondes. "
                        + "Aucune commande envoyée.");
                    release();
                }
            }, 5000L);
        } catch (SecurityException e) {
            report("Accès interdit par Android : " + e.getClass().getSimpleName());
            release();
        } catch (RuntimeException e) {
            report("Échec de connexion : " + e.getClass().getSimpleName() + " : " + e.getMessage());
            release();
        }
    }

    @Override public void onServiceConnected(ComponentName name, IBinder service) {
        String descriptor;
        try {
            descriptor = service == null ? "Binder null" : service.getInterfaceDescriptor();
        } catch (RemoteException | RuntimeException e) {
            descriptor = "Description indisponible : " + e.getClass().getSimpleName();
        }
        report("Connexion Binder établie (liaison uniquement). Interface : " + descriptor
            + ". Aucune fonction véhicule appelée.");
        release();
    }

    @Override public void onNullBinding(ComponentName name) {
        report("Le service a retourné un Binder nul : pas d'interface liée exposée.");
        release();
    }

    @Override public void onBindingDied(ComponentName name) {
        report("La liaison avec le service a été interrompue.");
        release();
    }

    @Override public void onServiceDisconnected(ComponentName name) {
        if (!finished) report("Le service s'est déconnecté pendant le test.");
        release();
    }

    public void release() {
        if (!bound) return;
        try { context.unbindService(this); }
        catch (IllegalArgumentException e) { Log.w(TAG, "unbind: " + e.getMessage()); }
        bound = false;
    }

    private void report(String message) {
        if (finished) return;
        finished = true;
        Log.i(TAG, message);
        if (listener != null) listener.onResult(message);
    }
}
