package com.aztech.voice;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

/**
 * V5.1 : diagnostic IPC non opérationnel, ciblant le plugin vocal Xiaoka.
 * Le seul accès Binder est getInterfaceDescriptor() : aucune méthode OEM,
 * transaction métier, propriété véhicule, commande CAN ou mouvement de vitre/toit.
 * BIND_AUTO_CREATE : Android peut démarrer le service ciblé. Aucun ordre véhicule.
 */
public final class SafeServiceProbe implements ServiceConnection {
    private static final String TAG = "AZVoiceProbe";
    private static final ComponentName TARGET = new ComponentName(
        "com.ecarx.xiaoka", "com.ecarx.xiaoka.service.plugin.XKPlugService");
    private static final String ACTION = "ecarx.intent.action.VR_PLUGIN_ACTION";
    private static final String CATEGORY = "ecarx.intent.category.VR_PLUGIN_CATEGORY";
    private static final long TIMEOUT_MS = 8000L;

    public interface Listener { void onResult(String message); }

    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;
    private boolean bound;
    private boolean inProgress;
    private Runnable timeout;

    public SafeServiceProbe(Context context) { this.context = context; }

    public void run(Listener nextListener) {
        if (inProgress) {
            nextListener.onResult("Un diagnostic de liaison est déjà en cours.");
            return;
        }
        inProgress = true;
        listener = nextListener;
        // Un Intent de liaison avec action documentée dans le manifeste, sans extras.
        Intent request = new Intent(ACTION).addCategory(CATEGORY).setComponent(TARGET);
        try {
            // Liaison Android standard avec démarrage automatique du service si nécessaire.
            // Peut exécuter du code d'initialisation constructeur : TEST UNIQUEMENT À L'ARRÊT.
            // AUCUN startService, transact, méthode constructeur ou commande mécanique.
            bound = context.bindService(request, this, Context.BIND_AUTO_CREATE);
            if (!bound) {
                finish("bindService=false : le service ne peut pas être lié avec BIND_AUTO_CREATE. "
                    + "Aucune commande véhicule envoyée.");
                return;
            }
            Log.i(TAG, "XKPLUG bindService=true ; BIND_AUTO_CREATE ; attente Binder (8 s max)");
            timeout = () -> {
                if (inProgress) finish("Délai dépassé (8 s) : aucune interface Binder reçue "
                    + "après BIND_AUTO_CREATE. Consulter logcat. Aucune commande véhicule envoyée.");
            };
            handler.postDelayed(timeout, TIMEOUT_MS);
        } catch (SecurityException e) {
            finish("Connexion interdite par Android : " + e.getClass().getSimpleName());
        } catch (RuntimeException e) {
            finish("Échec de liaison : " + e.getClass().getSimpleName() + " : " + e.getMessage());
        }
    }

    @Override public void onServiceConnected(ComponentName name, IBinder service) {
        if (!inProgress) return;
        if (service == null) {
            finish("Connexion reçue mais Binder absent. Aucune commande envoyée.");
            return;
        }
        try {
            // Lecture de l'identité IPC uniquement : aucune invocation fonctionnelle OEM.
            String descriptor = service.getInterfaceDescriptor();
            finish("BINDER REÇU — interface : " + (descriptor == null ? "(nulle)" : descriptor)
                + ". Aucune méthode de commande appelée.");
        } catch (RemoteException | RuntimeException e) {
            finish("Binder reçu, identifiant inaccessible : " + e.getClass().getSimpleName());
        }
    }

    @Override public void onNullBinding(ComponentName name) {
        finish("onNullBinding : XKPlugService a retourné un Binder nul malgré BIND_AUTO_CREATE. "
            + "Aucune commande véhicule envoyée.");
    }

    @Override public void onBindingDied(ComponentName name) {
        finish("Liaison avec XKPlugService interrompue par Android.");
    }

    @Override public void onServiceDisconnected(ComponentName name) {
        finish("Service Xiaoka déconnecté pendant le test.");
    }

    private void finish(String message) {
        if (!inProgress) return;
        inProgress = false;
        if (timeout != null) { handler.removeCallbacks(timeout); timeout = null; }
        Log.i(TAG, "XKPLUG " + message);
        releaseBinding();
        if (listener != null) listener.onResult(message);
        listener = null;
    }

    private void releaseBinding() {
        if (!bound) return;
        // Supprime seulement la liaison initiée par notre application.
        try { context.unbindService(this); }
        catch (IllegalArgumentException e) { Log.w(TAG, "unbindService : " + e.getMessage()); }
        finally { bound = false; }
    }

    /** Appelé à la fermeture de l'activité pour ne laisser aucune liaison active. */
    public void release() {
        inProgress = false;
        if (timeout != null) { handler.removeCallbacks(timeout); timeout = null; }
        releaseBinding();
        listener = null;
    }
}
