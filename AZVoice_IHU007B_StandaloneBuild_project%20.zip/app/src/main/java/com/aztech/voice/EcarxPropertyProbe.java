package com.aztech.voice;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.3: Lectures de trois propriétés globales, non actionnables et documentées.
 * Aucun appel OEM de commande, aucun set*, aucune transaction Binder brute,
 * aucune permission privilégiée demandée ni méthode de contournement.
 * Le test ne s'exécute qu'après une confirmation explicite sur la tablette.
 */
public final class EcarxPropertyProbe {
    public interface Listener { void onResult(String result); }
    private static final String TAG = "AZVoiceEcarx";
    private static final String PROPERTY_SERVICE = "property";
    private static final String[] READ_ONLY_PROPERTIES = {
        "ENGINE_RPM", "ENGINE_COOLANT_TEMP", "ENGINE_OIL_TEMP"
    };
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public EcarxPropertyProbe(Context ctx) { context = ctx.getApplicationContext(); }

    public void readOnce(Listener listener) {
        if (!busy.compareAndSet(false, true)) {
            listener.onResult("Diagnostic en cours : aucune lecture simultanée.");
            return;
        }
        new Thread(() -> {
            String s;
            try { s = runDiagnostic(); }
            catch (Throwable error) { s = "[ERREUR INATTENDUE] " + explain(error); }
            final String result = s;
            Log.i(TAG, "Début rapport V5.3 (lecture seule)");
            for (String line : result.split("\n")) Log.i(TAG, line);
            busy.set(false);
            ui.post(() -> listener.onResult(result));
        }, "AZVoice-ECARX-property-read").start();
    }

    private String runDiagnostic() {
        StringBuilder out = new StringBuilder("LECTURE PROPRIETES ECARX V5.3 (aucune commande)\n");
        Object car = null;
        try {
            ClassLoader cl = context.getClassLoader();
            Class<?> carType = Class.forName("android.car.Car", false, cl);
            Class<?> propertyIds = Class.forName("android.car.VehiclePropertyIds", false, cl);
            out.append("[OK] android.car.Car et VehiclePropertyIds accessibles.\n");
            Method create = findPublicStatic(carType,"createCar",Context.class);
            if (create != null) {
                out.append("[INFO] Car.createCar(Context) disponible.\n");
                car = create.invoke(null, context);
            } else {
                Method legacy = findPublicStatic(carType,"createCar",Context.class,ServiceConnection.class);
                if (legacy == null) {
                    out.append("[NON TENTE] Aucune signature createCar sûre et connue.\n");
                    return out.toString();
                }
                out.append("[INFO] Connexion Android 9 avec ServiceConnection.\n");
                CountDownLatch ready = new CountDownLatch(1);
                ServiceConnection connection = new ServiceConnection() {
                    @Override public void onServiceConnected(ComponentName n, IBinder binder) { ready.countDown(); }
                    @Override public void onServiceDisconnected(ComponentName n) { }
                };
                car = legacy.invoke(null, context, connection);
                if (car == null) {
                    out.append("[INDISPONIBLE] createCar a retourné null.\n");
                    return out.toString();
                }
                try {
                    Object connected = carType.getMethod("isConnected").invoke(car);
                    if (!Boolean.TRUE.equals(connected)) {
                        carType.getMethod("connect").invoke(car);
                        if (!ready.await(5, TimeUnit.SECONDS)) {
                            out.append("[DELAI] Aucun signal de connexion dans 5 secondes.\n");
                            return out.toString();
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    out.append("[INTERROMPU] Connexion interrompue.\n");
                    return out.toString();
                }
            }
            if (car == null) {
                out.append("[INDISPONIBLE] android.car.Car renvoie null.\n");
                return out.toString();
            }
            out.append("[OK] Objet android.car.Car créé.\n");
            try {
                Method connected = carType.getMethod("isConnected");
                if (!Boolean.TRUE.equals(connected.invoke(car))) {
                    out.append("[NON CONNECTE] isConnected=false, aucune lecture tentée.\n");
                    return out.toString();
                }
                out.append("[OK] isConnected=true.\n");
            } catch (NoSuchMethodException e) {
                out.append("[INFO] isConnected() non exposé ; vérification via getCarManager.\n");
            }
            Field propField;
            String propertyService;
            try {
                propField = carType.getField("PROPERTY_SERVICE");
                propertyService = (String)propField.get(null);
            } catch (NoSuchFieldException noConstant) {
                out.append("[INFO] PROPERTY_SERVICE absent ; utilisation du nom Android documenté.\n");
                propertyService = PROPERTY_SERVICE;
            }
            Object manager = carType.getMethod("getCarManager", String.class).invoke(car,propertyService);
            if (manager == null) {
                out.append("[INDISPONIBLE] getCarManager(property) = null.\n");
                return out.toString();
            }
            out.append("[OK] Gestionnaire de propriétés : ").append(manager.getClass().getName()).append("\n");
            Class<?> managerType = Class.forName("android.car.hardware.property.CarPropertyManager", false, cl);
            if (!managerType.isInstance(manager)) {
                out.append("[STOP] Type inattendu, aucune lecture tentée.\n");
                return out.toString();
            }
            Method configMethod = managerType.getMethod("getCarPropertyConfig", int.class);
            Method getter = managerType.getMethod("getFloatProperty", int.class, int.class);
            for (String name : READ_ONLY_PROPERTIES) {
                // Only exact official, non-actuating property names. No vendor ID scanning.
                out.append(name).append(" : ");
                try {
                    int propertyId = propertyIds.getField(name).getInt(null);
                    Object config = configMethod.invoke(manager, propertyId);
                    if (config == null) {
                        out.append("absente, non prise en charge ou lecture non autorisée.\n");
                        continue;
                    }
                    Object value = getter.invoke(manager,propertyId,0);
                    if (!(value instanceof Number)) {
                        out.append("type de valeur inattendu.\n");
                        continue;
                    }
                    out.append("valeur brute=").append(value)
                       .append(" ; zéro peut signifier moteur arrêté ou donnée indisponible.\n");
                } catch (Throwable error) {
                    Throwable t = root(error);
                    out.append(t instanceof SecurityException ? "PERMISSION REFUSEE : " : "ERREUR : ")
                       .append(explain(t)).append("\n");
                }
            }
            out.append("FIN - trois propriétés de lecture uniquement. Aucun setFunctionValue/setProperty.\n");
        } catch (Throwable e) {
            Throwable t=root(e);
            out.append(t instanceof SecurityException ? "[PERMISSION REFUSEE] " : "[ERREUR] ")
               .append(explain(t)).append("\n");
        } finally {
            if (car != null) {
                try { car.getClass().getMethod("disconnect").invoke(car); }
                catch (Throwable ignored) { out.append("[INFO] Libération de connexion non confirmée.\n"); }
            }
        }
        return out.toString();
    }

    private static Method findPublicStatic(Class<?> t, String n, Class<?>... params) {
        try {
            Method m=t.getMethod(n,params);
            return Modifier.isStatic(m.getModifiers()) ? m : null;
        } catch (NoSuchMethodException e) { return null; }
    }
    private static Throwable root(Throwable e) {
        if (e instanceof InvocationTargetException && ((InvocationTargetException)e).getTargetException()!=null)
            return ((InvocationTargetException)e).getTargetException();
        return e;
    }
    private static String explain(Throwable e) {
        Throwable t=root(e);
        String msg=t.getMessage();
        return t.getClass().getSimpleName() + (msg == null ? "" : " : " + msg);
    }
}
