package com.aztech.voice;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.4 : diagnostic de fonctions constructeur BCM / HVAC en lecture seule.
 * Aucun getFunctionValue, setFunctionValue, setProperty, transaction Binder brute,
 * lancement de service arbitraire, ou modification des permissions.
 * La seconde phase invoque seulement isFunctionSupported(int) sur 8 fonctions
 * explicites et non sur une plage inconnue d'identifiants.
 */
public final class BcmHvacProbe {
    public interface Listener { void onResult(String result); }
    private static final String TAG = "AZVoiceBcmHvac";
    private static final String OEM_CAR = "com.ecarx.xui.adaptapi.car.Car";
    private static final String BCM = "com.ecarx.xui.adaptapi.car.vehicle.IBcm$BcmFunction";
    private static final String HVAC = "com.ecarx.xui.adaptapi.car.hvac.IHvac$HvacFunction";
    private static final String[][] FUNCTIONS = {
        {BCM, "BCM_FUNC_WINDOW", "Vitres / fonctions generales"},
        {BCM, "BCM_FUNC_WINDOW_POS", "Position vitres / toit selon configuration"},
        {BCM, "BCM_FUNC_WINDOW_CURRENT_POS", "Position courante"},
        {BCM, "BCM_FUNC_SUNROOF_TILT", "Inclinaison toit"},
        {HVAC, "HVAC_FUNC_AC", "Climatisation A/C"},
        {HVAC, "HVAC_FUNC_TEMP", "Temperature de consigne"},
        {HVAC, "HVAC_FUNC_FAN_SPEED", "Ventilation"},
        {HVAC, "HVAC_FUNC_AUTO", "Climatisation automatique"}
    };
    private static final String[] PERMISSIONS = {
        "android.car.permission.CONTROL_CAR_WINDOWS",
        "android.car.permission.CONTROL_CAR_CLIMATE",
        "android.car.permission.CAR_VENDOR_EXTENSION"
    };
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    public BcmHvacProbe(Context ctx) { context = ctx.getApplicationContext(); }

    public void inspectStatic(Listener cb) { start(false, cb); }
    public void checkSupport(Listener cb) { start(true, cb); }

    private void start(boolean support, Listener cb) {
        if (!busy.compareAndSet(false, true)) {
            cb.onResult("Diagnostic BCM/HVAC deja en cours.");
            return;
        }
        new Thread(() -> {
            String result;
            try { result = run(support); }
            catch (Throwable e) { result = "[ERREUR] " + explain(e); }
            Log.i(TAG, support ? "V5.4 TEST SUPPORT BCM/HVAC" : "V5.4 INSPECTION BCM/HVAC");
            for (String line : result.split("\n")) Log.i(TAG, line);
            busy.set(false);
            final String output = result;
            ui.post(() -> cb.onResult(output));
        }, support ? "AZVoice-bcmhvac-support" : "AZVoice-bcmhvac-static").start();
    }

    private String run(boolean support) {
        StringBuilder out = new StringBuilder("AZ VOICE V5.4 - BCM / HVAC (aucune commande physique)\n");
        ClassLoader loader = context.getClassLoader();
        out.append("Inspection de 8 fonctions connues, sans enumeration d'ID OEM inconnus.\n");
        out.append("Permissions de l'APK (aucune demande d'octroi) :\n");
        for (String permission : PERMISSIONS) {
            try {
                boolean granted = context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
                out.append("  ").append(permission).append(" : ")
                   .append(granted ? "ACCORDEE" : "NON ACCORDEE").append('\n');
            } catch (Throwable t) {
                out.append("  ").append(permission).append(" : erreur ").append(explain(t)).append('\n');
            }
        }
        Object carFunctions = null;
        Method supportMethod = null;
        if (support) {
            try {
                Class<?> carType = Class.forName(OEM_CAR, false, loader);
                Method create = carType.getMethod("create", Context.class);
                if (!Modifier.isStatic(create.getModifiers())) {
                    out.append("[STOP] Car.create(Context) n'est pas statique.\n");
                    return out.toString();
                }
                Object car = create.invoke(null, context);
                if (car == null) {
                    out.append("[STOP] Car.create(Context) renvoie null.\n");
                    return out.toString();
                }
                out.append("[OK] Car.create : ").append(car.getClass().getName()).append('\n');
                carFunctions = car.getClass().getMethod("getICarFunction").invoke(car);
                if (carFunctions == null) {
                    out.append("[STOP] getICarFunction() renvoie null.\n");
                    return out.toString();
                }
                out.append("[OK] ICarFunction : ").append(carFunctions.getClass().getName()).append('\n');
                supportMethod = carFunctions.getClass().getMethod("isFunctionSupported", int.class);
                out.append("[OK] isFunctionSupported(int) disponible.\n");
            } catch (Throwable e) {
                out.append("[STOP] Initialisation OEM ou methode indisponible : ").append(explain(e)).append('\n');
                return out.toString();
            }
        } else {
            out.append("Mode statique : Car.create et services constructeurs NON invoques.\n");
        }
        for (String[] entry : FUNCTIONS) {
            String owner = entry[0], fieldName = entry[1], purpose = entry[2];
            out.append(fieldName).append(" (").append(purpose).append(") : ");
            try {
                Class<?> type = Class.forName(owner, false, loader);
                Field field = type.getField(fieldName);
                if (field.getType() != int.class || !Modifier.isStatic(field.getModifiers())) {
                    out.append("ID non entier statique : test ignore.\n");
                    continue;
                }
                int id = field.getInt(null);
                out.append("ID=0x").append(Integer.toHexString(id));
                if (support) {
                    try {
                        Object status = supportMethod.invoke(carFunctions, id);
                        out.append(" ; isFunctionSupported = ")
                           .append(status == null ? "null" : status.toString());
                        out.append(" (statut brut, pas une autorisation d'ecriture)");
                    } catch (Throwable e) {
                        out.append(" ; consultation echouee : ").append(explain(e));
                    }
                }
                out.append('\n');
            } catch (Throwable e) {
                out.append("constante indisponible : ").append(explain(e)).append('\n');
            }
        }
        out.append("FIN - aucune lecture de valeur, aucun setFunctionValue, setProperty ou mouvement.\n");
        out.append("Un retour SUPPORTED n'accorde PAS CONTROL_CAR_WINDOWS ou les droits HVAC.\n");
        return out.toString();
    }
    private static Throwable unwrap(Throwable t) {
        int count = 0;
        while (t instanceof InvocationTargetException && count++ < 4) {
            Throwable cause = ((InvocationTargetException)t).getTargetException();
            if (cause == null || cause == t) break;
            t = cause;
        }
        return t;
    }
    private static String explain(Throwable error) {
        Throwable root = unwrap(error);
        String message = root.getMessage();
        return root.getClass().getSimpleName() + (message == null ? "" : ": " + message);
    }
}
