package com.aztech.voice;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * V5.4.2 : diagnostic de fonctions constructeur BCM / HVAC en lecture seule.
 * Aucun getFunctionValue, setFunctionValue, setProperty, transaction Binder brute,
 * lancement de service arbitraire, ou modification des permissions.
 * La seconde phase invoque seulement isFunctionSupported(int) sur 8 fonctions
 * explicites et non sur une plage inconnue d'identifiants.
 */
public final class BcmHvacProbe {
    public interface Listener { void onResult(String result); }
    private static final String TAG = "AZVoiceBcmHvac";
    private static final String OEM_CAR = "com.ecarx.xui.adaptapi.car.Car";
    private static final String BCM = "com.ecarx.xui.adaptapi.car.vehicle.IBcm";
    private static final String HVAC = "com.ecarx.xui.adaptapi.car.hvac.IHvac";
    private static final String[][] FUNCTIONS = {
        {BCM, "BCM_FUNC_WINDOW", "Vitres / fonctions generales"},
        {BCM, "BCM_FUNC_WINDOW_POS", "Position vitres / toit selon configuration"},
        {BCM, "BCM_FUNC_WINDOW_CURRENT_POS", "Position courante"},
        {BCM, "BCM_FUNC_SUNROOF_TILT", "Inclinaison toit"},
        {HVAC, "HVAC_FUNC_AC", "Climatisation A/C"},
        {HVAC, "HVAC_FUNC_TEMP", "Temperature de consigne"},
        {HVAC, "HVAC_FUNC_FAN_SPEED", "Ventilation"},
        {HVAC, "HVAC_FUNC_AUTO", "Climatisation automatique"}
    };
    private static final String[] PERMISSIONS = {
        "android.car.permission.CONTROL_CAR_WINDOWS",
        "android.car.permission.CONTROL_CAR_CLIMATE",
        "android.car.permission.CAR_VENDOR_EXTENSION"
    };
    private final Context context;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    public BcmHvacProbe(Context ctx) { context = ctx.getApplicationContext(); }

    public void inspectStatic(Listener cb) { start(false, cb); }
    public void checkSupport(Listener cb) { start(true, cb); }

    private void start(boolean support, Listener cb) {
        if (!busy.compareAndSet(false, true)) {
            cb.onResult("Diagnostic BCM/HVAC deja en cours.");
            return;
        }
        new Thread(() -> {
            String result;
            try { result = run(support); }
            catch (Throwable e) { result = "[ERREUR] " + explain(e); }
            Log.i(TAG, support ? "V5.4.2 TEST SUPPORT BCM/HVAC" : "V5.4.2 INSPECTION BCM/HVAC");
            for (String line : result.split("\n")) Log.i(TAG, line);
            busy.set(false);
            final String output = result;
            ui.post(() -> cb.onResult(output));
        }, support ? "AZVoice-bcmhvac-support" : "AZVoice-bcmhvac-static").start();
    }

    /**
     * A single scoped diagnostic.  Calls connect() on ECARX ICar and does not
     * interrogate support until isConnected() confirms the OEM channel.
     * No reading of unknown properties, no writes, no motion commands.
     */
    private String run(boolean support) {
        StringBuilder out = new StringBuilder("AZ VOICE V5.4.2 - BCM / HVAC (aucune commande physique)\n");
        ClassLoader loader = context.getClassLoader();
        out.append("Inspection des 8 fonctions documentees seulement.\n");
        out.append("Permissions de l'APK (aucune demande d'octroi) :\n");
        for (String permission : PERMISSIONS) {
            try {
                boolean granted = context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
                out.append("  ").append(permission).append(" : ")
                   .append(granted ? "ACCORDEE" : "NON ACCORDEE").append('\n');
            } catch (Throwable t) {
                out.append("  ").append(permission).append(" : erreur ").append(explain(t)).append('\n');
            }
        }

        Object car = null;
        boolean attemptedConnect = false;
        try {
            Object carFunctions = null;
            Method supportMethod = null;
            if (support) {
                try {
                    Class<?> carType = Class.forName(OEM_CAR, false, loader);
                    Method create = carType.getMethod("create", Context.class);
                    if (!Modifier.isStatic(create.getModifiers())) {
                        out.append("[STOP] Car.create(Context) n'est pas statique.\n");
                        return out.toString();
                    }
                    car = create.invoke(null, context);
                    if (car == null) {
                        out.append("[STOP] Car.create(Context) renvoie null.\n");
                        return out.toString();
                    }
                    out.append("[OK] Car.create : ").append(car.getClass().getName()).append('\n');

                    // ICar extends the OEM connection infrastructure through
                    // VehicleSignalManager; Android Car.isConnected is different.
                    Method connect = car.getClass().getMethod("connect");
                    Method connected = car.getClass().getMethod("isConnected");
                    boolean ready = Boolean.TRUE.equals(connected.invoke(car));
                    out.append("[OEM] isConnected avant connect : ").append(ready).append('\n');
                    if (!ready) {
                        out.append("[OEM] Appel unique ICar.connect() (aucune commande BCM/HVAC).\n");
                        attemptedConnect = true;
                        connect.invoke(car);
                        final long deadline = android.os.SystemClock.elapsedRealtime() + 8000;
                        while (android.os.SystemClock.elapsedRealtime() < deadline) {
                            ready = Boolean.TRUE.equals(connected.invoke(car));
                            if (ready) break;
                            Thread.sleep(200);
                        }
                    }
                    out.append("[OEM] isConnected apres connexion : ").append(ready).append('\n');
                    if (!ready) {
                        out.append("[STOP] ECARX ICar non connecte apres 8 s : AUCUN isFunctionSupported invoque.\n");
                        return out.toString();
                    }

                    carFunctions = car.getClass().getMethod("getICarFunction").invoke(car);
                    if (carFunctions == null) {
                        out.append("[STOP] getICarFunction() renvoie null.\n");
                        return out.toString();
                    }
                    out.append("[OK] ICarFunction : ").append(carFunctions.getClass().getName()).append('\n');
                    supportMethod = carFunctions.getClass().getMethod("isFunctionSupported", int.class);
                    out.append("[OK] isFunctionSupported(int) disponible.\n");
                } catch (Throwable e) {
                    if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                    out.append("[STOP] Connexion ECARX ou methode indisponible : ").append(explain(e)).append('\n');
                    return out.toString();
                }
            } else {
                out.append("Mode statique : Car.create et services constructeurs NON invoques.\n");
            }

            for (String[] entry : FUNCTIONS) {
                String owner = entry[0], fieldName = entry[1], purpose = entry[2];
                out.append(fieldName).append(" (").append(purpose).append(") : ");
                try {
                    Class<?> type = Class.forName(owner, false, loader);
                    Field field = type.getField(fieldName);
                    if (field.getType() != int.class || !Modifier.isStatic(field.getModifiers())) {
                        out.append("ID non entier statique : test ignore.\n");
                        continue;
                    }
                    int id = field.getInt(null);
                    out.append("ID=0x").append(Integer.toHexString(id));
                    if (support) {
                        try {
                            Object status = supportMethod.invoke(carFunctions, id);
                            out.append(" ; isFunctionSupported = ")
                               .append(status == null ? "null" : status.toString());
                            out.append(" (indication de support, NON une autorisation d'action)");
                        } catch (Throwable e) {
                            out.append(" ; consultation echouee : ").append(explain(e));
                        }
                    }
                    out.append('\n');
                } catch (Throwable e) {
                    out.append("constante indisponible : ").append(explain(e)).append('\n');
                }
            }
            out.append("FIN - aucun getFunctionValue, setFunctionValue, setProperty ou mouvement.\n");
            out.append("SUPPORTED n'accorde PAS CONTROL_CAR_WINDOWS ni CONTROL_CAR_CLIMATE.\n");
            return out.toString();
        } finally {
            // Close only a connection explicitly opened by this invocation.
            // Calls disconnect() on OEM ICar, never the vehicle actuators.
            if (attemptedConnect && car != null) {
                try {
                    car.getClass().getMethod("disconnect").invoke(car);
                    Log.i(TAG, "[OEM] Diagnostic termine : ICar.disconnect() effectue.");
                } catch (Throwable t) {
                    Log.w(TAG, "[OEM] Nettoyage connexion : " + explain(t));
                }
            }
        }
    }
    private static Throwable unwrap(Throwable t) {
        int count = 0;
        while (t instanceof InvocationTargetException && count++ < 4) {
            Throwable cause = ((InvocationTargetException)t).getTargetException();
            if (cause == null || cause == t) break;
            t = cause;
        }
        return t;
    }
    private static String explain(Throwable error) {
        Throwable root = unwrap(error);
        String message = root.getMessage();
        return root.getClass().getSimpleName() + (message == null ? "" : ": " + message);
    }
}
