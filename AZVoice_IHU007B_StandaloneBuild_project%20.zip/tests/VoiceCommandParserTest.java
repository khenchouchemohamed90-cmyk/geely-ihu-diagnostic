import com.aztech.voice.VoiceCommandParser;

public class VoiceCommandParserTest {
    static int passed;
    static void expect(String utterance, String action, String target) {
        VoiceCommandParser.Command c = VoiceCommandParser.parse(utterance);
        if (action == null) {
            if (c != null) throw new AssertionError("Expected reject for '"+utterance+"' but got " + c.label);
        } else if (c == null || !action.equals(c.type) || !target.equals(c.target)) {
            throw new AssertionError("Unexpected parse for '" + utterance + "': " + (c==null?"null":c.type+":"+c.target));
        }
        passed++;
    }
    public static void main(String[] args) {
        expect("ouvre la vitre conducteur", "OUVRIR", "AVANT_GAUCHE");
        expect("ferme la vitre du passager", "FERMER", "AVANT_DROITE");
        expect("Ouvre la vitre arrière gauche", "OUVRIR", "ARRIERE_GAUCHE");
        expect("ferme vitre arrière droite", "FERMER", "ARRIERE_DROITE");
        expect("baisse la vitre avant gauche", "OUVRIR", "AVANT_GAUCHE");
        expect("remonte la vitre avant droite", "FERMER", "AVANT_DROITE");
        expect("ferme toutes les vitres", "FERMER", "TOUTES_VITRES");
        expect("ouvre toutes les fenêtres", "OUVRIR", "TOUTES_VITRES");
        expect("ouvre le toit ouvrant", "OUVRIR", "TOIT_OUVRANT");
        expect("ferme le toit panoramique", "FERMER", "TOIT_OUVRANT");
        expect("arrête le toit ouvrant", "ARRETER", "TOIT_OUVRANT");
        expect("AZ Voice ouvre la vitre chauffeur", "OUVRIR", "AVANT_GAUCHE");
        expect("bonjour", null, null);
        expect("démarre la voiture", null, null);
        expect("ouvre", null, null);
        expect("ouvre la vitre", null, null);
        expect("ferme la vitre arrière", null, null);
        expect("ouvre vitre gauche", null, null);
        expect("ferme la vitre conducteur et passager", null, null);
        expect("ouvre puis ferme toutes les vitres", null, null);
        expect("ne ferme pas la vitre conducteur", null, null);
        expect("n'ouvre pas le toit ouvrant", null, null);
        expect("stop la vitre conducteur", null, null);
        expect("ferme le toit", null, null);
        expect("ferme toutes les vitres arrière", null, null);
        expect("ouvre la vitre avant gauche et droite", null, null);
        expect("", null, null);
        System.out.println("TESTS OK: "+passed+"/"+passed+" parser tests passed");
    }
}
