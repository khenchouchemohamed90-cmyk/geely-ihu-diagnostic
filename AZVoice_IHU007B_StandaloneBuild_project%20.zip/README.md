# AZ Voice V5.2 — Diagnostic AdapterAPI (IHU007B)

Le projet conserve les fonctions de V5.1 : Vosk FR (MIC 1), commandes vitres et toit **en simulation**, et diagnostic XKPlugService avec BIND_AUTO_CREATE.

## Nouveaux tests distincts

1. **Inspecter les classes AdapterAPI** : uniquement `Class.forName(name, false, loader)` et `getDeclaredMethods()`. Aucune initialisation de classe OEM ou appel métier. Les noms trouvés prouvent seulement la visibilité de l'API depuis une APK ordinaire.
2. **Tester Car.create et ICarFunction** : après confirmation explicite dans l'interface, l'application cherche puis invoque uniquement `Car.create(Context)` et l'accesseur `getICarFunction()`. La fonction peut initialiser du code OEM et connecter des services; tester véhicule immobilisé. Aucun `getFunctionValue()`, `setFunctionValue()`, aucune transaction CAN, aucune commande moteur ou écriture.

Les résultats sont affichés et enregistrés sous `AZVoiceEcarx` :

```
logcat -d -s AZVoiceEcarx:I '*:S'
```

**Ce qu'un résultat positif ne démontre pas :** accès aux propriétés, privilèges `CONTROL_CAR_WINDOWS`, ou fonctionnement des équipements physiques.

## Compilation

Le ZIP s'installe à la place du ZIP source à la racine du dépôt GitHub `AZVoice_IHU007B_StandaloneBuild_project%20.zip` (nom littéral contenant `%20`). Ne pas changer `.github/workflows/build-apk.yml` du dépôt : le workflow existant extrait ce ZIP, télécharge le modèle Vosk FR et compile `assembleDebug`.

Application distincte `com.aztech.voice.v52`, Android 9 minimum, Java 8, pas de permission OEM. Compilation GitHub encore à réaliser.

## Tests

`bash scripts/test-parser.sh` (27 scénarios). Ne pas installer les APK constructeur ni modifier le firmware ou les permissions système. Aucun test en conduite.
