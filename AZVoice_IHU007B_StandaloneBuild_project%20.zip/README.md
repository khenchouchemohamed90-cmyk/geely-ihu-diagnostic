# AZ Voice V5.4 — BCM et HVAC (diagnostic lecture seule)

Base V5.3.1, Android 9 (SDK 28), armeabi-v8a; application autonome `com.aztech.voice.v54`.

### Nouveaux tests
- **4A — Inventaire statique BCM/HVAC :** résout précisément huit constantes BCM/HVAC et vérifie les permissions du package sans initialiser de service constructeur.
- **4B — Vérifier fonctions BCM/HVAC :** après confirmation explicite, appelle `Car.create(Context)`, `getICarFunction()` et **uniquement** `isFunctionSupported(int)` pour huit constantes connues `IBcm$BcmFunction` et `IHvac$HvacFunction`.
- Aucune lecture de valeur de fonctions mécaniques, aucune écriture `setFunctionValue`, aucune transaction Binder brute, pas de root ni ajout de permissions automobiles. Les réponses de `isFunctionSupported` ne prouvent ni le droit de commande ni l'aptitude de l'équipement à bouger sans risque.
- Reconnaissance française Vosk et autres diagnostics V5.3.1 conservés.

### Journal et sécurité
`logcat -d -s AZVoiceBcmHvac:I '*:S'`

Tests uniquement véhicule immobilisé; **aucun actionnement des vitres, toit ouvrant ou climatisation**. Les fonctions peuvent être indisponibles, masquées ou protégées par le constructeur.

### Compilation GitHub
Déposer ce ZIP au nom exact `AZVoice_IHU007B_StandaloneBuild_project%20.zip` à la racine du dépôt `khenchouchemohamed90-cmyk/geely-ihu-diagnostic`; workflow existant inchangé.
