# AZ Voice V5 — diagnostic du plugin Xiaoka (IHU007B)

Android 9 / API 28 / ARM64. Application autonome compatible avec le projet V4.

## Objectif du test

- Reconnaissance française Vosk hors ligne, `MIC (1)` par défaut.
- Commandes françaises de vitres/toit reconnues uniquement en **simulation**.
- Test d’une liaison Android standard vers `com.ecarx.xiaoka/.service.plugin.XKPlugService`.
- L’Intent porte l’action `ecarx.intent.action.VR_PLUGIN_ACTION` et la catégorie `ecarx.intent.category.VR_PLUGIN_CATEGORY`, identifiées dans le manifeste Xiaoka.
- **Aucun extra, aucune méthode du Binder OEM, aucune transaction fonctionnelle, aucun ordre aux vitres/toit**.
- `bindService(..., flags=0)` : aucun démarrage automatique (`BIND_AUTO_CREATE` absent). L’identité du Binder est lue par `getInterfaceDescriptor()` uniquement en cas de liaison réussie.
- Résultat affiché à l’écran et dans `logcat -d -s AZVoiceProbe:I '*:S'`.
- Déconnexion automatique après réponse ou délai de 5 secondes.

## Limites

- Un Binder retourné **ne signifie pas** permission d’utiliser les fonctions véhicule.
- Si `bindService=false`, le service peut être indisponible plutôt qu’inaccessible ; cela ne prouve pas qu’une intégration est impossible.
- Ne pas tester en roulant ; conserver Xiaoka/ECARX et le système véhicule inchangés.

## Compiler

Le dépôt utilisateur a un workflow `.github/workflows/build-apk.yml` qui installe Android 34, Java 17, Gradle 8.7 et le modèle `vosk-model-small-fr-0.22`, puis compile `app-debug.apk`.

## Tests locaux

`bash scripts/test-parser.sh` exécute les 27 scénarios de commandes vocales simulées.
