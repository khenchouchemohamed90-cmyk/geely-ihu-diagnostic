# AZ Voice V3 — Commandes françaises (simulation)

Projet expérimental Geely IHU007B / Android 9, compatible ARM64.

**Sécurité : aucune fonction du véhicule n'est commandée.** Aucune dépendance ECARX, aucun appel à CarPropertyManager ou aux services constructeur, aucune commande ADB/CAN, aucune permission Android automobile. Bouton de confirmation **SIMULATION uniquement**. Aucun démarrage moteur, commande de vitres, toit, portes ou climatisation.

## Fonctions

- Microphone **MIC (1) sélectionné par défaut**, car la source VOICE_RECOGNITION (6) déformait la voix sur l'IHU testé.
- Modèle Vosk français hors ligne `vosk-model-small-fr-0.22`, téléchargé et intégré pendant la compilation GitHub Actions.
- Mesure RMS, pic et échantillons audio, capture WAV locale 8 s volontaire.
- Détection de commandes françaises précises :
  - « Ouvre/Ferme la vitre conducteur », « Ouvre/Ferme la vitre passager ».
  - « Ouvre/Ferme la vitre arrière gauche/droite ».
  - « Ouvre/Ferme toutes les vitres ».
  - « Ouvre/Ferme le toit ouvrant », « Arrête le toit ouvrant ».
- Propose une confirmation ou une annulation **sans action réelle**; refuse les commandes ambiguës.
- Le code du parseur est en Java pur et dispose de tests autonomes.

## Installation et compatibilité

Package **`com.aztech.voice.v3`** : installation à côté de V2 (`com.aztech.voice`), sans désinstaller la V2 ni perdre ses enregistrements. **Fermer V2 avant d'utiliser V3**, car le microphone peut être exclusif. Minimum API 28, target API 28, compile API 34. L'autorisation demandée est `RECORD_AUDIO` uniquement.

## Compilation

Téléverser cette archive ZIP dans le dépôt GitHub **avec le nom exact** `AZVoice_IHU007B_StandaloneBuild_project .zip` (note : un espace AVANT `.zip`). Le workflow déjà configuré dans le dépôt décompresse ce fichier et publie l'APK dans les Artifacts du run. L'archive contient également une copie cohérente du workflow à titre de référence.

Tests du parseur sans SDK : `bash scripts/test-parser.sh`.

**Statut : projet prêt à compiler, APK V3 non encore produite ni testée sur l'IHU.**
