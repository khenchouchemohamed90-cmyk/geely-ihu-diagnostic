# AZ Voice V5.4.2 — Diagnostic ECARX connexion d'abord

Conserve la reconnaissance française et les outils de diagnostic précédents.

Le test 4B suit désormais l'ordre : `Car.create(Context)` → `ICar.isConnected()` → `ICar.connect()` si nécessaire → attente de connexion **au plus 8 secondes** → `getICarFunction()` → `isFunctionSupported(int)` sur huit identifiants connus → `ICar.disconnect()` si la connexion a été demandée par ce test.

Si le service constructeur ne se connecte pas, **le test s'arrête** sans interrogation BCM/HVAC.

Le test 4A n'initialise aucun service. Aucun `getFunctionValue`, `setFunctionValue`, `setProperty`, aucune commande de vitres, de toit, de climatisation ou de mouvement. Ce diagnostic ne modifie pas les permissions Android, ne nécessite pas de root, et ne désactive aucune application système.

Note de prudence : `connect()` démarre du code constructeur ; véhicule immobilisé seulement. Les résultats de `isFunctionSupported` ne sont pas des autorisations d'action.

## Compiler

Le workflow GitHub existant s'applique au fichier `AZVoice_IHU007B_StandaloneBuild_project%20.zip`. Compilation : `:app:assembleDebug`.

## Journaux

```sh
logcat -d -s AZVoiceBcmHvac:I '*:S'
```
