# AZ Voice V5.4.3 — diagnostic ECARX avec observateur de connexion

Projet de diagnostic pour Geely Emgrand IHU007B (Android 9), à compiler avec le workflow GitHub existant.

Le test **4B** effectue uniquement :

1. `Car.create(Context)` et `isConnected()` ;
2. si disponible, `registerConnectWatcher(IConnectWatcher)` avant `connect()` ;
3. une connexion constructeur avec un délai maximal de 8 s et observation de `onConnected()` ;
4. identification en lecture seule de `ECarxCarConfigManager` (sans appel à son API) ;
5. deux consultations `isFunctionSupported(int)` pour les huit identifiants BCM/HVAC connus, espacées de 1,2 s ;
6. désinscription de l'observateur et fermeture de la connexion initiée par l'application.

Le test **4A** reste purement statique. Le traitement en français par Vosk et les commandes **simulées** sont conservés.

**Limitations :** `isConnected=true` et une éventuelle notification `onConnected()` ne prouvent pas que `car_config` est opérationnel ; `notavailable` n'est pas une preuve de refus de permission. Aucun appel `getFunctionValue()`, `setFunctionValue()`, `setProperty()` ; aucune activation des vitres, du toit ou de la climatisation ; aucune désactivation des protections constructeur.

Installation distincte : `com.aztech.voice.v543`. Effectuer l'essai exclusivement véhicule immobilisé. `connect()` initialise du code OEM.

## Compiler

Déposer le ZIP sous le nom exact `AZVoice_IHU007B_StandaloneBuild_project%20.zip` dans le dépôt GitHub existant. L'APK sera dans les **Artifacts** de l'exécution GitHub Actions.

## Consulter les journaux

```sh
logcat -d -s AZVoiceBcmHvac:I '*:S'
```
