# AZ Voice V5.1 — BIND_AUTO_CREATE sur XKPlugService (IHU007B)

Android 9 / API 28 / ARM64. Application autonome compatible avec le projet V4.

## Objectif du test

- Reconnaissance française Vosk hors ligne, `MIC (1)` par défaut.
- Commandes françaises de vitres/toit reconnues uniquement en **simulation**.
- Test d’une liaison Android standard vers `com.ecarx.xiaoka/.service.plugin.XKPlugService`.
- L’Intent porte l’action `ecarx.intent.action.VR_PLUGIN_ACTION` et la catégorie `ecarx.intent.category.VR_PLUGIN_CATEGORY`, identifiées dans le manifeste Xiaoka.
- **Aucun extra, aucune méthode du Binder OEM, aucune transaction fonctionnelle, aucun ordre aux vitres/toit**.
- `bindService(..., Context.BIND_AUTO_CREATE)` : Android peut démarrer le service constructeur pour la liaison (une initialisation interne peut se produire). L’identité du Binder est lue par `getInterfaceDescriptor()` uniquement en cas de liaison réussie.
- Résultat affiché à l’écran et dans `logcat -d -s AZVoiceProbe:I '*:S'`.
- Déconnexion automatique après réponse ou délai de 8 secondes.

## Limites

- Un Binder retourné **ne signifie pas** permission d’utiliser les fonctions véhicule.
- Si `bindService=false`, `onNullBinding` ou délai dépassé, voir logcat ; chaque résultat est distingué explicitement. Aucun appel Binder métier.
- Ne pas tester en roulant ; conserver Xiaoka/ECARX et le système véhicule inchangés.

## Compiler

Pour GitHub, remplacer le fichier racine `AZVoice_IHU007B_StandaloneBuild_project%20.zip` sans le renommer. Le dépôt utilisateur a un workflow `.github/workflows/build-apk.yml` qui installe Android 34, Java 17, Gradle 8.7 et le modèle `vosk-model-small-fr-0.22`, puis compile `app-debug.apk`.

## Tests locaux

`bash scripts/test-parser.sh` exécute les 27 scénarios de commandes vocales simulées.

## Sécurité et résultats

- **Tester uniquement avec le véhicule immobilisé**. BIND_AUTO_CREATE peut déclencher du code dans le service OEM.
- V5.1 utilise un nouvel identifiant d'application `com.aztech.voice.v51` : peut être installé à côté de V5, sans désinstallation.
- Le bouton de test demande seulement une liaison et la lecture de `IBinder.getInterfaceDescriptor()` ; pas de `transact`, de commande de vitres/toit, d'écriture CarService ou CAN.
- Diagnostic : `logcat -d -s AZVoiceProbe:I "*:S"`
- Ne rien déduire d'un Binder reçu quant aux permissions d'actionner les organes du véhicule.
