# AZ Voice V4 — diagnostic liaison ECARX (non operationnel)

Geely Emgrand IHU007B, Android 9, ARM64. Projet experimental.

## Objectif

Tester par clic volontaire si une application tierce Android peut se lier au service deja actif
`com.ecarx.xiaoka.carcontrol/.service.CarControlService`.

- `bindService` explicite, indicateur **0** (pas `BIND_AUTO_CREATE`).
- Sur retour d'un Binder, **uniquement** `IBinder.getInterfaceDescriptor()`.
- Jamais d'appel de methode constructeur, transaction de controle, intent de commande, mouvement du toit/vitres,
  privilege systeme, root, modification de firmware ou permission automobile.
- Un test peut toutefois declencher les callbacks standards `onBind()`/`onUnbind()` du service distant :
  aucune absence absolue d'effet de bord interne ne peut etre garantie sans son code complet.
- Service non expose / interface absente / refus de permission : le resultat s'affiche, aucune tentative de contournement.
- Le fonctionnement des commandes reste **SIMULATION** : confirmation sans action.
- La V3 et la V2 restent installees cote a cote ; le package de la V4 est `com.aztech.voice.v4`.

## Procedure

1. Installer l'APK produite et autoriser uniquement RECORD_AUDIO si necessaire.
2. Voiture immobilisee, sans occupation des vitres/toit, ouvrir AZ Voice V4.
3. Appuyer explicitement sur `Tester la liaison au service Xiaoka`.
4. Noter le message precise sous le bouton.
5. Pour analyser le diagnostic : `logcat -d -s AZVoiceProbe:I '*:S'`.

## Compil GitHub

Remplacer le fichier `AZVoice_IHU007B_StandaloneBuild_project%20.zip` du depot par cette archive au meme nom.
Le workflow actuel sur `main` pointe deja vers ce nom.

Tests du parseur de commandes : `bash scripts/test-parser.sh`.
