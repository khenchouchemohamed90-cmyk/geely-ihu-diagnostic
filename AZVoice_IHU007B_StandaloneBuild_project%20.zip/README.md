# AZ Voice V5.4.5 — Diagnostic car_config par zones (lecture seule)

# AZ Voice V5.4.5 — CarConfig en lecture seule

Pour IHU007B Android 9 ARM64. Cette version conserve tous les tests AZ Voice V5.4.3, et ajoute un bouton **5. Examiner le gestionnaire car_config (SANS COMMANDE)**.

## Nouveau diagnostic

- Connexion à Android `car_service` via l'API publique présente sur l'IHU.
- Appel ciblé `getCarManager("car_config")`, sous l'identité de l'APK `com.aztech.voice.v545`.
- Si le gestionnaire existe, tentative de `isSupportFunctionSupported(id,0,0)` uniquement sur les SIX propriétés documentées dans les journaux HAL : `0x2E700121`, `0x2E700125`, `0x2E700127`, `0x2E700128`, `0x2E70012D`, `0x2E700249`.
- Affichage des **statuts bruts** et refus de permission, sans supposer la signification de 0/1/2/3 ni de zone=0.
- AUCUN `setProperty`, `setFunctionValue`, `getProperty(byte[])`, aucune modification de permissions, aucun autre appel OEM.

Installer et tester à l'arrêt. Journal :

```sh
logcat -d -s AZVoiceCarConfig:I '*:S'
```

Pour compiler sur GitHub, remplacer le fichier du dépôt `AZVoice_IHU007B_StandaloneBuild_project%20.zip` (avec un signe `%` dans le nom) par le ZIP produit. Le workflow en place doit charger ce fichier. L'identifiant APK est `com.aztech.voice.v545`.

Ce test ne fournit pas l'accès aux fonctions physiques : celles-ci restent régies par les permissions constructeur et les sécurités d'origine.

## Nouveau test de zone

Le bouton 5 compare les réponses de `ECarxCarConfigManager.isSupportFunctionSupported(propertyId, zone, 0)` pour **six propriétés déjà relevées dans le dump HAL** et uniquement les zones `VehicleZone` du firmware : avant gauche, avant droite, première rangée, toit ouvrant. Aucun balayage de propriétés, aucune opération non documentée, aucune écriture ni actionnement.

Journal : `logcat -d -s AZVoiceCarConfig:I '*:S'`. Les réponses brutes ne constituent pas une autorisation d’action.
