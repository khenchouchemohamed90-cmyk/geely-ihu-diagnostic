# AZ Voice V5.3.1 — Correctif Android 9 CarPropertyManager

- Application Android 9 ARM64, package autonome `com.aztech.voice.v531` pour éviter un conflit de signature APK avec V5.3.
- Reconnaissance Vosk, inspection AdapterAPI, Car.create() et test XKPlugService conservés.
- Correctif à l'erreur V5.3 `NoSuchMethodException: getCarPropertyConfig [int]`.
- Essaye `getCarPropertyConfig(int)` si présent, sinon `getPropertyList()` et recherche **seulement** des trois ID explicites standard `ENGINE_RPM`, `ENGINE_COOLANT_TEMP`, `ENGINE_OIL_TEMP`.
- Si aucune méthode d'inventaire n'existe, tente uniquement `getFloatProperty(int,int)` pour ces 3 ID non actionnables et distingue les erreurs d'autorisation.
- Aucune commande véhicule : pas de setProperty, setFunctionValue, scan de propriétés vendeur, contrôle des vitres/toit/clim ou contournement de permissions.
- Valeur 0 ambiguë sur certaines versions Android : ne pas interpréter comme mesure fiable sans contexte.
- Test à l'arrêt via le bouton `3. Lire RPM et températures (SANS COMMANDE)`.
- Logs : `logcat -d -s AZVoiceEcarx:I '*:S'`.

## Compiler sur GitHub

Téléverser **ce ZIP** sous le nom exact `AZVoice_IHU007B_StandaloneBuild_project%20.zip` à la racine du dépôt GitHub existant. Workflow `.github/workflows/build-apk.yml` inchangé.
