# AZ Voice V5.3 — Diagnostic propriétés ECARX en lecture seule

- Application Android 9 (API 28), arm64-v8a. Identifiant `com.aztech.voice.v53`.
- Reconnaissance vocale française Vosk identique à V5.2, source MIC (1), commandes simulées.
- Tests précédents conservés : inspection AdapterAPI, Car.create() et XKPlugService.
- Nouveau bouton `3. Lire RPM et températures (SANS COMMANDE)` avec confirmation explicite.
- Connexion à `android.car.Car` puis `CarPropertyManager` par réflexion (API Android), seulement les 3 propriétés `ENGINE_RPM`, `ENGINE_COOLANT_TEMP`, `ENGINE_OIL_TEMP`.
- Ne lit une propriété que si `getCarPropertyConfig()` est visible ; aucune permission spéciale n'est déclarée ; refus attendu possible sous Android 9.
- Aucun `setFunctionValue`, `setProperty`, `Runtime.exec`, transaction Binder brute ou code de commande véhicule.
- Journal : `logcat -d -s AZVoiceEcarx:I '*:S'`.
- **Important** : première lecture à l'arrêt ; la valeur zéro est ambiguë ; absence de résultat ne signifie pas absence du capteur.

## Compilation

Téléverser le ZIP dans le dépôt GitHub à la place de `AZVoice_IHU007B_StandaloneBuild_project%20.zip`. Le workflow existant du dépôt est configuré pour ce nom. Les outils téléchargent le modèle Vosk français durant le build.

## Limites

La lecture de propriétés moteur peut nécessiter la permission privilégiée `android.car.permission.CAR_ENGINE_DETAILED`. L'APK ne la demande pas et ne contourne pas les protections constructeur.
