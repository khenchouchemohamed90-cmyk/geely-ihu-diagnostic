from pathlib import Path
import os, subprocess, json
root=Path('/workspace/work/model-validation-audio')
env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/work/model-validation-espeak/root/usr/lib/x86_64-linux-gnu';env['XDG_CONFIG_HOME']=str(root)
negatives={
 'neg-musique':"ne lance pas la musique",
 'neg-clim':"n'allume pas la climatisation",
 'neg-pause':"ne mets pas la musique en pause",
 'neg-volonte':"je ne veux pas de musique",
 'contra-clim':"allume la climatisation et éteins la climatisation",
 'contra-open':"ouvre la navigation et le téléphone",
 'contra-serial':"lance la musique puis ouvre la navigation",
 'unknown-bonjour':"bonjour comment vas tu",
 'unknown-station':"je cherche une station service",
 'unknown-manger':"je vais manger demain",
}
for name,text in negatives.items():
 raw=root/(name+'-raw.wav');out=root/(name+'.wav')
 subprocess.run(['/workspace/work/model-validation-espeak/root/usr/bin/espeak-ng','--path=/workspace/work/model-validation-espeak/root/usr/lib/x86_64-linux-gnu','-v','fr-fr','-s','140','-w',str(raw),text],env=env,check=True)
 subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(raw),'-ar','16000','-ac','1','-c:a','pcm_s16le','-af','apad=pad_dur=1',str(out)],check=True)
(root/'negative-phrases.json').write_text(json.dumps(negatives,ensure_ascii=False,indent=2)+'\n')
phrases={}
for name in ['phrases.json','phrases175.json','negative-phrases.json']: phrases.update(json.loads((root/name).read_text()))
command=['/workspace/work/model-validation-venv/bin/python','tools/test_vosk_host.py','--grammar','/workspace/work/model-validation-grammar.json','--report','/workspace/work/model-validation-host-grammar.json']
for name,text in phrases.items(): command+=['--case',str(root/(name+'.wav'))+'='+text]
with open('/workspace/work/model-validation-host-grammar.log','w') as log:
 result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
print('host grammar smoke exit',result.returncode)
