import com.aztech.jarvisfr.FrenchIntentParser;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class ParserProbe {
 public static void main(String[] args) throws Exception {
  BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
  String line;
  while ((line = r.readLine()) != null) {
   FrenchIntentParser.Command c = FrenchIntentParser.parseCommand(line);
   System.out.println(c.intent.name() + "\t" + c.argument);
  }
 }
}
