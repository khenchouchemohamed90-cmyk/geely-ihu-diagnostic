import com.aztech.jarvisfr.FrenchVoiceGrammar;
public class GrammarProbe { public static void main(String[] args) { System.out.println(FrenchVoiceGrammar.json()); } }
